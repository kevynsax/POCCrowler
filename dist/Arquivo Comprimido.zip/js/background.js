/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1];
/******/ 		var executeModules = data[2];
/******/
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fulfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fulfilled = false;
/******/ 			}
/******/ 			if(fulfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 	// Promise = chunk loading, 0 = chunk loaded
/******/ 	var installedChunks = {
/******/ 		"background": 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push(["./src/background.ts","vendor"]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/background.ts":
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const types_1 = __webpack_require__(/*! ./types */ "./src/types.ts");
const queryInfo = {
    active: true,
    currentWindow: true
};
const store = "SusepData";
const storeConfig = "ConfigAxaCrowler";
const storage = chrome.storage.local;
const urlSusep = "http://www2.susep.gov.br/menuestatistica/SES/premiosesinistros.aspx?id=54";
const urlAxa = "https://www.axa.com.br/";
let tabId = 0;
let count = 0;
chrome.runtime.onMessage.addListener((msg, info, sendResponse) => {
    const lstHandlers = [
        { type: types_1.msgType.startProcess, handler: startProcess },
        { type: types_1.msgType.insertData, handler: handleInsert },
        { type: types_1.msgType.getNext, handler: getNext },
        { type: types_1.msgType.getCrowlerIsActive, handler: getIsActive },
        { type: types_1.msgType.getDataToExport, handler: getDataToExport },
        { type: types_1.msgType.getAggregatedCompanies, handler: getAggregatedCompanies },
        { type: types_1.msgType.finishiesExportSpreadSheet, handler: handleFinishiesExport },
        { type: types_1.msgType.cleanStorage, handler: cleanStorageAndGoToAxaSite },
        { type: types_1.msgType.getConfigs, handler: handlerGetConfigs },
        { type: types_1.msgType.saveConfigs, handler: handleUpdateConfigs },
        { type: types_1.msgType.resetConfigs, handler: resetConfigs },
    ];
    const { handler } = lstHandlers.find(x => x.type === msg.type) || { handler: null };
    if (!handler)
        return;
    handler(msg, sendResponse);
    return true;
});
const updateCounter = (n = null) => {
    count = n || count - 1;
    if (count === -1)
        count = null;
    const labelCount = (count || "").toString();
    chrome.browserAction.setBadgeText({ text: labelCount });
};
const startProcess = (msg) => getConfigs(configs => {
    const { periodoFinal, periodoInicial } = msg.payload;
    updateCounter(configs.markets.length * 2);
    cleanStorage();
    storage.set({ [store]: configs.markets.map(x => ({
            nome: x.nome,
            idRamos: x.idRamos,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
            dadosEmpresaAnoPassado: [],
            dadosEmpresaAtual: [],
            buscouDadosEmprAtual: false,
            buscouDadosEmprPassado: false
        })) });
    chrome.tabs.query(queryInfo, tabs => {
        tabId = tabs[0].id;
        openUrl();
    });
});
const getIsActive = (msg, sendResponse) => storage.get(store, response => {
    const storeData = response[store];
    sendResponse(!!storeData);
});
const openUrl = (url = urlSusep) => chrome.tabs.update(tabId, { url });
const getLastYear = (mkt) => ({
    nome: mkt.nome,
    idRamos: mkt.idRamos,
    periodoInicial: mkt.periodoInicial - 100,
    periodoFinal: mkt.periodoFinal - 100
});
const getNext = (msg, sendResponse) => storage.get(store, response => {
    const results = response[store];
    if (!results) {
        sendResponse(null);
        return;
    }
    const nextActualYear = results.find(x => !x.buscouDadosEmprAtual);
    if (!!nextActualYear) {
        updateCounter();
        sendResponse(nextActualYear);
        return;
    }
    const nextLastYear = results.find(x => !x.buscouDadosEmprPassado);
    if (!!nextLastYear) {
        updateCounter();
        sendResponse(getLastYear(nextLastYear));
        return;
    }
    updateCounter();
    sendResponse(null);
    return;
});
const handleInsert = (msg) => insertData(msg, () => openUrl());
const insertData = (msg, callBack) => storage.get(store, response => {
    const results = response[store];
    const payload = msg.payload;
    const meta = payload.metadata;
    let mkt = results.find(x => equalsMarket(x, meta));
    if (mkt.periodoInicial === meta.periodoInicial) {
        mkt.dadosEmpresaAtual = payload.tableData;
        mkt.buscouDadosEmprAtual = true;
    }
    else {
        mkt.dadosEmpresaAnoPassado = payload.tableData;
        mkt.buscouDadosEmprPassado = true;
    }
    const newValues = [...results.filter(x => !equalsMarket(x, meta)), mkt];
    storage.set({ [store]: newValues }, callBack);
});
const equalsMarket = (src, to) => {
    const createHash = (lst) => lst.sort((a, b) => a - b).join(",");
    return createHash(src.idRamos) === createHash(to.idRamos);
};
const getDataToExport = (msg, sendResponse) => storage.get(store, response => {
    const lst = response[store];
    const hasToDo = lst && !!lst.find(x => !x.buscouDadosEmprAtual || !x.buscouDadosEmprPassado);
    if (hasToDo) {
        sendResponse(null);
        return;
    }
    sendResponse(lst);
});
const cleanStorageAndGoToAxaSite = () => cleanStorage(() => openUrl(urlAxa));
const cleanStorage = (callBack = () => { }) => storage.remove(store, callBack);
const updateConfigs = (cfg, callBack) => storage.set({ [storeConfig]: cfg }, callBack);
const handleUpdateConfigs = (msg, sendresponse) => updateConfigs(msg.payload, sendresponse);
const getAggregatedCompanies = (msg, sendReponse) => getConfigs(configs => sendReponse(configs.aggregatedCompanies));
const handlerGetConfigs = (msg, sendResponse) => getConfigs(sendResponse);
const getConfigs = (callback) => storage.get(storeConfig, response => {
    var configs = response[storeConfig];
    if (!configs) {
        setupConfigs(() => getConfigs(callback));
        return;
    }
    callback(configs);
});
const handleFinishiesExport = (msg, sendResponse) => getConfigs(cfgs => {
    if (!cfgs.generateRawData) {
        cleanStorageAndGoToAxaSite();
        return;
    }
    openUrl(urlAxa);
});
const resetConfigs = (msg, sendResponse) => setupConfigs(sendResponse);
//todo completar lista de grupos empresariais
const setupConfigs = callback => {
    const idDpvat = 588;
    const mkts = [
        { nome: "Aviation", idRamos: [1528, 1535, 1537, 1597] },
        { nome: "Financial Lines", idRamos: [310, 378] },
        { nome: "Cargo", idRamos: [621, 622, 632, 638, 652, 654, 655, 656, 658] },
        { nome: "Casualty", idRamos: [351] },
        { nome: "Construction", idRamos: [167] },
        { nome: "Environmental", idRamos: [313] },
        { nome: "Port", idRamos: [1417] },
        //        { nome: "Property", idRamos: [196, 141, 118] },
        { nome: "PRCB", idRamos: [748, 749] },
        { nome: "Property RNO", idRamos: [196] },
        { nome: "Property Compr. Emp.", idRamos: [118] },
        { nome: "Property Total", idRamos: [196, 141, 118] },
        { nome: "Marine Hull", idRamos: [1433] },
        { nome: "cyber", idRamos: [327] },
        { nome: "Surety", idRamos: [775, 776] },
        { nome: "Condomínio", idRamos: [116] },
        { nome: "Miscellaneous", idRamos: [171] },
    ];
    const allIds = mkts.map(x => x.idRamos).reduce((all, item) => [...all, ...item], []);
    updateConfigs({
        markets: [
            ...mkts,
            { nome: "Total sem DPVAT", idRamos: allIds },
            { nome: "DPVAT", idRamos: [idDpvat] },
            { nome: "Total com DPVAT", idRamos: [...allIds, idDpvat] },
        ],
        aggregatedCompanies: [
            { nome: "MAPFRE BANCO DO BRASIL", idEmpresas: [6238, 6211, 6785, 6181, 3289] },
            { nome: "PORTO SEGURO", idEmpresas: [5886, 5355, 3182, 6033] },
            { nome: "ZURICH", idEmpresas: [5495, 5941, 6564] },
            { nome: "HDI", idEmpresas: [1571, 6572] },
            { nome: "AXA", idEmpresas: [1431, 2852, 6696], isAxa: true },
            { nome: "BRADESCO", idEmpresas: [5312, 5533] },
            { nome: "COFACE", idEmpresas: [6335] },
            { nome: "ICATU", idEmpresas: [5142, 5657] },
            { nome: "SAFRA", idEmpresas: [1627, 9938] },
            { nome: "ALFA", idEmpresas: [6467, 2895] },
            { nome: "CAPEMISA", idEmpresas: [4251, 1741] },
            { nome: "COMPREV", idEmpresas: [1937, 2879] },
            { nome: "INVESTPREV", idEmpresas: [6921, 6173] },
        ],
        generateRawData: false,
        nameExportedFile: "Template comparativo de mercado"
    }, callback);
};


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2JhY2tncm91bmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZ0JBQVEsb0JBQW9CO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQWlCLDRCQUE0QjtBQUM3QztBQUNBO0FBQ0EsMEJBQWtCLDJCQUEyQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxrREFBMEMsZ0NBQWdDO0FBQzFFO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZ0VBQXdELGtCQUFrQjtBQUMxRTtBQUNBLHlEQUFpRCxjQUFjO0FBQy9EOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBeUMsaUNBQWlDO0FBQzFFLHdIQUFnSCxtQkFBbUIsRUFBRTtBQUNySTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLG1DQUEyQiwwQkFBMEIsRUFBRTtBQUN2RCx5Q0FBaUMsZUFBZTtBQUNoRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw4REFBc0QsK0RBQStEOztBQUVySDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQWdCLHVCQUF1QjtBQUN2Qzs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUN0SmE7QUFDYiw4Q0FBOEMsY0FBYztBQUM1RCxnQkFBZ0IsbUJBQU8sQ0FBQywrQkFBUztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsNERBQTREO0FBQ3JFLFNBQVMsMERBQTBEO0FBQ25FLFNBQVMsa0RBQWtEO0FBQzNELFNBQVMsaUVBQWlFO0FBQzFFLFNBQVMsa0VBQWtFO0FBQzNFLFNBQVMsZ0ZBQWdGO0FBQ3pGLFNBQVMsbUZBQW1GO0FBQzVGLFNBQVMsMEVBQTBFO0FBQ25GLFNBQVMsK0RBQStEO0FBQ3hFLFNBQVMsa0VBQWtFO0FBQzNFLFNBQVMsNERBQTREO0FBQ3JFO0FBQ0EsV0FBVyxVQUFVLGtEQUFrRDtBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLG1CQUFtQjtBQUMxRDtBQUNBO0FBQ0EsV0FBVywrQkFBK0I7QUFDMUM7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxJQUFJO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0QsK0RBQStELE1BQU07QUFDckU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLHFCQUFxQjtBQUN0QyxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0Esd0NBQXdDLEVBQUU7QUFDMUMsc0RBQXNELHFCQUFxQjtBQUMzRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsc0RBQXNEO0FBQy9ELFNBQVMsK0NBQStDO0FBQ3hELFNBQVMsd0VBQXdFO0FBQ2pGLFNBQVMsbUNBQW1DO0FBQzVDLFNBQVMsdUNBQXVDO0FBQ2hELFNBQVMsd0NBQXdDO0FBQ2pELFNBQVMsZ0NBQWdDO0FBQ3pDLG1CQUFtQiw2Q0FBNkM7QUFDaEUsU0FBUyxvQ0FBb0M7QUFDN0MsU0FBUyx1Q0FBdUM7QUFDaEQsU0FBUywrQ0FBK0M7QUFDeEQsU0FBUyxtREFBbUQ7QUFDNUQsU0FBUyx1Q0FBdUM7QUFDaEQsU0FBUyxnQ0FBZ0M7QUFDekMsU0FBUyxzQ0FBc0M7QUFDL0MsU0FBUyxxQ0FBcUM7QUFDOUMsU0FBUyx3Q0FBd0M7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWEsMkNBQTJDO0FBQ3hELGFBQWEsb0NBQW9DO0FBQ2pELGFBQWEseURBQXlEO0FBQ3RFO0FBQ0E7QUFDQSxhQUFhLDZFQUE2RTtBQUMxRixhQUFhLDZEQUE2RDtBQUMxRSxhQUFhLGlEQUFpRDtBQUM5RCxhQUFhLHdDQUF3QztBQUNyRCxhQUFhLDJEQUEyRDtBQUN4RSxhQUFhLDZDQUE2QztBQUMxRCxhQUFhLHFDQUFxQztBQUNsRCxhQUFhLDBDQUEwQztBQUN2RCxhQUFhLDBDQUEwQztBQUN2RCxhQUFhLHlDQUF5QztBQUN0RCxhQUFhLDZDQUE2QztBQUMxRCxhQUFhLDRDQUE0QztBQUN6RCxhQUFhLCtDQUErQztBQUM1RDtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wiLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIGluc3RhbGwgYSBKU09OUCBjYWxsYmFjayBmb3IgY2h1bmsgbG9hZGluZ1xuIFx0ZnVuY3Rpb24gd2VicGFja0pzb25wQ2FsbGJhY2soZGF0YSkge1xuIFx0XHR2YXIgY2h1bmtJZHMgPSBkYXRhWzBdO1xuIFx0XHR2YXIgbW9yZU1vZHVsZXMgPSBkYXRhWzFdO1xuIFx0XHR2YXIgZXhlY3V0ZU1vZHVsZXMgPSBkYXRhWzJdO1xuXG4gXHRcdC8vIGFkZCBcIm1vcmVNb2R1bGVzXCIgdG8gdGhlIG1vZHVsZXMgb2JqZWN0LFxuIFx0XHQvLyB0aGVuIGZsYWcgYWxsIFwiY2h1bmtJZHNcIiBhcyBsb2FkZWQgYW5kIGZpcmUgY2FsbGJhY2tcbiBcdFx0dmFyIG1vZHVsZUlkLCBjaHVua0lkLCBpID0gMCwgcmVzb2x2ZXMgPSBbXTtcbiBcdFx0Zm9yKDtpIDwgY2h1bmtJZHMubGVuZ3RoOyBpKyspIHtcbiBcdFx0XHRjaHVua0lkID0gY2h1bmtJZHNbaV07XG4gXHRcdFx0aWYoaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdKSB7XG4gXHRcdFx0XHRyZXNvbHZlcy5wdXNoKGluc3RhbGxlZENodW5rc1tjaHVua0lkXVswXSk7XG4gXHRcdFx0fVxuIFx0XHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkXSA9IDA7XG4gXHRcdH1cbiBcdFx0Zm9yKG1vZHVsZUlkIGluIG1vcmVNb2R1bGVzKSB7XG4gXHRcdFx0aWYoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1vcmVNb2R1bGVzLCBtb2R1bGVJZCkpIHtcbiBcdFx0XHRcdG1vZHVsZXNbbW9kdWxlSWRdID0gbW9yZU1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHRcdH1cbiBcdFx0fVxuIFx0XHRpZihwYXJlbnRKc29ucEZ1bmN0aW9uKSBwYXJlbnRKc29ucEZ1bmN0aW9uKGRhdGEpO1xuXG4gXHRcdHdoaWxlKHJlc29sdmVzLmxlbmd0aCkge1xuIFx0XHRcdHJlc29sdmVzLnNoaWZ0KCkoKTtcbiBcdFx0fVxuXG4gXHRcdC8vIGFkZCBlbnRyeSBtb2R1bGVzIGZyb20gbG9hZGVkIGNodW5rIHRvIGRlZmVycmVkIGxpc3RcbiBcdFx0ZGVmZXJyZWRNb2R1bGVzLnB1c2guYXBwbHkoZGVmZXJyZWRNb2R1bGVzLCBleGVjdXRlTW9kdWxlcyB8fCBbXSk7XG5cbiBcdFx0Ly8gcnVuIGRlZmVycmVkIG1vZHVsZXMgd2hlbiBhbGwgY2h1bmtzIHJlYWR5XG4gXHRcdHJldHVybiBjaGVja0RlZmVycmVkTW9kdWxlcygpO1xuIFx0fTtcbiBcdGZ1bmN0aW9uIGNoZWNrRGVmZXJyZWRNb2R1bGVzKCkge1xuIFx0XHR2YXIgcmVzdWx0O1xuIFx0XHRmb3IodmFyIGkgPSAwOyBpIDwgZGVmZXJyZWRNb2R1bGVzLmxlbmd0aDsgaSsrKSB7XG4gXHRcdFx0dmFyIGRlZmVycmVkTW9kdWxlID0gZGVmZXJyZWRNb2R1bGVzW2ldO1xuIFx0XHRcdHZhciBmdWxmaWxsZWQgPSB0cnVlO1xuIFx0XHRcdGZvcih2YXIgaiA9IDE7IGogPCBkZWZlcnJlZE1vZHVsZS5sZW5ndGg7IGorKykge1xuIFx0XHRcdFx0dmFyIGRlcElkID0gZGVmZXJyZWRNb2R1bGVbal07XG4gXHRcdFx0XHRpZihpbnN0YWxsZWRDaHVua3NbZGVwSWRdICE9PSAwKSBmdWxmaWxsZWQgPSBmYWxzZTtcbiBcdFx0XHR9XG4gXHRcdFx0aWYoZnVsZmlsbGVkKSB7XG4gXHRcdFx0XHRkZWZlcnJlZE1vZHVsZXMuc3BsaWNlKGktLSwgMSk7XG4gXHRcdFx0XHRyZXN1bHQgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IGRlZmVycmVkTW9kdWxlWzBdKTtcbiBcdFx0XHR9XG4gXHRcdH1cbiBcdFx0cmV0dXJuIHJlc3VsdDtcbiBcdH1cblxuIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gb2JqZWN0IHRvIHN0b3JlIGxvYWRlZCBhbmQgbG9hZGluZyBjaHVua3NcbiBcdC8vIHVuZGVmaW5lZCA9IGNodW5rIG5vdCBsb2FkZWQsIG51bGwgPSBjaHVuayBwcmVsb2FkZWQvcHJlZmV0Y2hlZFxuIFx0Ly8gUHJvbWlzZSA9IGNodW5rIGxvYWRpbmcsIDAgPSBjaHVuayBsb2FkZWRcbiBcdHZhciBpbnN0YWxsZWRDaHVua3MgPSB7XG4gXHRcdFwiYmFja2dyb3VuZFwiOiAwXG4gXHR9O1xuXG4gXHR2YXIgZGVmZXJyZWRNb2R1bGVzID0gW107XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cbiBcdHZhciBqc29ucEFycmF5ID0gd2luZG93W1wid2VicGFja0pzb25wXCJdID0gd2luZG93W1wid2VicGFja0pzb25wXCJdIHx8IFtdO1xuIFx0dmFyIG9sZEpzb25wRnVuY3Rpb24gPSBqc29ucEFycmF5LnB1c2guYmluZChqc29ucEFycmF5KTtcbiBcdGpzb25wQXJyYXkucHVzaCA9IHdlYnBhY2tKc29ucENhbGxiYWNrO1xuIFx0anNvbnBBcnJheSA9IGpzb25wQXJyYXkuc2xpY2UoKTtcbiBcdGZvcih2YXIgaSA9IDA7IGkgPCBqc29ucEFycmF5Lmxlbmd0aDsgaSsrKSB3ZWJwYWNrSnNvbnBDYWxsYmFjayhqc29ucEFycmF5W2ldKTtcbiBcdHZhciBwYXJlbnRKc29ucEZ1bmN0aW9uID0gb2xkSnNvbnBGdW5jdGlvbjtcblxuXG4gXHQvLyBhZGQgZW50cnkgbW9kdWxlIHRvIGRlZmVycmVkIGxpc3RcbiBcdGRlZmVycmVkTW9kdWxlcy5wdXNoKFtcIi4vc3JjL2JhY2tncm91bmQudHNcIixcInZlbmRvclwiXSk7XG4gXHQvLyBydW4gZGVmZXJyZWQgbW9kdWxlcyB3aGVuIHJlYWR5XG4gXHRyZXR1cm4gY2hlY2tEZWZlcnJlZE1vZHVsZXMoKTtcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuY29uc3QgdHlwZXNfMSA9IHJlcXVpcmUoXCIuL3R5cGVzXCIpO1xuY29uc3QgcXVlcnlJbmZvID0ge1xuICAgIGFjdGl2ZTogdHJ1ZSxcbiAgICBjdXJyZW50V2luZG93OiB0cnVlXG59O1xuY29uc3Qgc3RvcmUgPSBcIlN1c2VwRGF0YVwiO1xuY29uc3Qgc3RvcmVDb25maWcgPSBcIkNvbmZpZ0F4YUNyb3dsZXJcIjtcbmNvbnN0IHN0b3JhZ2UgPSBjaHJvbWUuc3RvcmFnZS5sb2NhbDtcbmNvbnN0IHVybFN1c2VwID0gXCJodHRwOi8vd3d3Mi5zdXNlcC5nb3YuYnIvbWVudWVzdGF0aXN0aWNhL1NFUy9wcmVtaW9zZXNpbmlzdHJvcy5hc3B4P2lkPTU0XCI7XG5jb25zdCB1cmxBeGEgPSBcImh0dHBzOi8vd3d3LmF4YS5jb20uYnIvXCI7XG5sZXQgdGFiSWQgPSAwO1xubGV0IGNvdW50ID0gMDtcbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobXNnLCBpbmZvLCBzZW5kUmVzcG9uc2UpID0+IHtcbiAgICBjb25zdCBsc3RIYW5kbGVycyA9IFtcbiAgICAgICAgeyB0eXBlOiB0eXBlc18xLm1zZ1R5cGUuc3RhcnRQcm9jZXNzLCBoYW5kbGVyOiBzdGFydFByb2Nlc3MgfSxcbiAgICAgICAgeyB0eXBlOiB0eXBlc18xLm1zZ1R5cGUuaW5zZXJ0RGF0YSwgaGFuZGxlcjogaGFuZGxlSW5zZXJ0IH0sXG4gICAgICAgIHsgdHlwZTogdHlwZXNfMS5tc2dUeXBlLmdldE5leHQsIGhhbmRsZXI6IGdldE5leHQgfSxcbiAgICAgICAgeyB0eXBlOiB0eXBlc18xLm1zZ1R5cGUuZ2V0Q3Jvd2xlcklzQWN0aXZlLCBoYW5kbGVyOiBnZXRJc0FjdGl2ZSB9LFxuICAgICAgICB7IHR5cGU6IHR5cGVzXzEubXNnVHlwZS5nZXREYXRhVG9FeHBvcnQsIGhhbmRsZXI6IGdldERhdGFUb0V4cG9ydCB9LFxuICAgICAgICB7IHR5cGU6IHR5cGVzXzEubXNnVHlwZS5nZXRBZ2dyZWdhdGVkQ29tcGFuaWVzLCBoYW5kbGVyOiBnZXRBZ2dyZWdhdGVkQ29tcGFuaWVzIH0sXG4gICAgICAgIHsgdHlwZTogdHlwZXNfMS5tc2dUeXBlLmZpbmlzaGllc0V4cG9ydFNwcmVhZFNoZWV0LCBoYW5kbGVyOiBoYW5kbGVGaW5pc2hpZXNFeHBvcnQgfSxcbiAgICAgICAgeyB0eXBlOiB0eXBlc18xLm1zZ1R5cGUuY2xlYW5TdG9yYWdlLCBoYW5kbGVyOiBjbGVhblN0b3JhZ2VBbmRHb1RvQXhhU2l0ZSB9LFxuICAgICAgICB7IHR5cGU6IHR5cGVzXzEubXNnVHlwZS5nZXRDb25maWdzLCBoYW5kbGVyOiBoYW5kbGVyR2V0Q29uZmlncyB9LFxuICAgICAgICB7IHR5cGU6IHR5cGVzXzEubXNnVHlwZS5zYXZlQ29uZmlncywgaGFuZGxlcjogaGFuZGxlVXBkYXRlQ29uZmlncyB9LFxuICAgICAgICB7IHR5cGU6IHR5cGVzXzEubXNnVHlwZS5yZXNldENvbmZpZ3MsIGhhbmRsZXI6IHJlc2V0Q29uZmlncyB9LFxuICAgIF07XG4gICAgY29uc3QgeyBoYW5kbGVyIH0gPSBsc3RIYW5kbGVycy5maW5kKHggPT4geC50eXBlID09PSBtc2cudHlwZSkgfHwgeyBoYW5kbGVyOiBudWxsIH07XG4gICAgaWYgKCFoYW5kbGVyKVxuICAgICAgICByZXR1cm47XG4gICAgaGFuZGxlcihtc2csIHNlbmRSZXNwb25zZSk7XG4gICAgcmV0dXJuIHRydWU7XG59KTtcbmNvbnN0IHVwZGF0ZUNvdW50ZXIgPSAobiA9IG51bGwpID0+IHtcbiAgICBjb3VudCA9IG4gfHwgY291bnQgLSAxO1xuICAgIGlmIChjb3VudCA9PT0gLTEpXG4gICAgICAgIGNvdW50ID0gbnVsbDtcbiAgICBjb25zdCBsYWJlbENvdW50ID0gKGNvdW50IHx8IFwiXCIpLnRvU3RyaW5nKCk7XG4gICAgY2hyb21lLmJyb3dzZXJBY3Rpb24uc2V0QmFkZ2VUZXh0KHsgdGV4dDogbGFiZWxDb3VudCB9KTtcbn07XG5jb25zdCBzdGFydFByb2Nlc3MgPSAobXNnKSA9PiBnZXRDb25maWdzKGNvbmZpZ3MgPT4ge1xuICAgIGNvbnN0IHsgcGVyaW9kb0ZpbmFsLCBwZXJpb2RvSW5pY2lhbCB9ID0gbXNnLnBheWxvYWQ7XG4gICAgdXBkYXRlQ291bnRlcihjb25maWdzLm1hcmtldHMubGVuZ3RoICogMik7XG4gICAgY2xlYW5TdG9yYWdlKCk7XG4gICAgc3RvcmFnZS5zZXQoeyBbc3RvcmVdOiBjb25maWdzLm1hcmtldHMubWFwKHggPT4gKHtcbiAgICAgICAgICAgIG5vbWU6IHgubm9tZSxcbiAgICAgICAgICAgIGlkUmFtb3M6IHguaWRSYW1vcyxcbiAgICAgICAgICAgIHBlcmlvZG9JbmljaWFsOiBwZXJpb2RvSW5pY2lhbCxcbiAgICAgICAgICAgIHBlcmlvZG9GaW5hbDogcGVyaW9kb0ZpbmFsLFxuICAgICAgICAgICAgZGFkb3NFbXByZXNhQW5vUGFzc2FkbzogW10sXG4gICAgICAgICAgICBkYWRvc0VtcHJlc2FBdHVhbDogW10sXG4gICAgICAgICAgICBidXNjb3VEYWRvc0VtcHJBdHVhbDogZmFsc2UsXG4gICAgICAgICAgICBidXNjb3VEYWRvc0VtcHJQYXNzYWRvOiBmYWxzZVxuICAgICAgICB9KSkgfSk7XG4gICAgY2hyb21lLnRhYnMucXVlcnkocXVlcnlJbmZvLCB0YWJzID0+IHtcbiAgICAgICAgdGFiSWQgPSB0YWJzWzBdLmlkO1xuICAgICAgICBvcGVuVXJsKCk7XG4gICAgfSk7XG59KTtcbmNvbnN0IGdldElzQWN0aXZlID0gKG1zZywgc2VuZFJlc3BvbnNlKSA9PiBzdG9yYWdlLmdldChzdG9yZSwgcmVzcG9uc2UgPT4ge1xuICAgIGNvbnN0IHN0b3JlRGF0YSA9IHJlc3BvbnNlW3N0b3JlXTtcbiAgICBzZW5kUmVzcG9uc2UoISFzdG9yZURhdGEpO1xufSk7XG5jb25zdCBvcGVuVXJsID0gKHVybCA9IHVybFN1c2VwKSA9PiBjaHJvbWUudGFicy51cGRhdGUodGFiSWQsIHsgdXJsIH0pO1xuY29uc3QgZ2V0TGFzdFllYXIgPSAobWt0KSA9PiAoe1xuICAgIG5vbWU6IG1rdC5ub21lLFxuICAgIGlkUmFtb3M6IG1rdC5pZFJhbW9zLFxuICAgIHBlcmlvZG9JbmljaWFsOiBta3QucGVyaW9kb0luaWNpYWwgLSAxMDAsXG4gICAgcGVyaW9kb0ZpbmFsOiBta3QucGVyaW9kb0ZpbmFsIC0gMTAwXG59KTtcbmNvbnN0IGdldE5leHQgPSAobXNnLCBzZW5kUmVzcG9uc2UpID0+IHN0b3JhZ2UuZ2V0KHN0b3JlLCByZXNwb25zZSA9PiB7XG4gICAgY29uc3QgcmVzdWx0cyA9IHJlc3BvbnNlW3N0b3JlXTtcbiAgICBpZiAoIXJlc3VsdHMpIHtcbiAgICAgICAgc2VuZFJlc3BvbnNlKG51bGwpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG5leHRBY3R1YWxZZWFyID0gcmVzdWx0cy5maW5kKHggPT4gIXguYnVzY291RGFkb3NFbXByQXR1YWwpO1xuICAgIGlmICghIW5leHRBY3R1YWxZZWFyKSB7XG4gICAgICAgIHVwZGF0ZUNvdW50ZXIoKTtcbiAgICAgICAgc2VuZFJlc3BvbnNlKG5leHRBY3R1YWxZZWFyKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBuZXh0TGFzdFllYXIgPSByZXN1bHRzLmZpbmQoeCA9PiAheC5idXNjb3VEYWRvc0VtcHJQYXNzYWRvKTtcbiAgICBpZiAoISFuZXh0TGFzdFllYXIpIHtcbiAgICAgICAgdXBkYXRlQ291bnRlcigpO1xuICAgICAgICBzZW5kUmVzcG9uc2UoZ2V0TGFzdFllYXIobmV4dExhc3RZZWFyKSk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdXBkYXRlQ291bnRlcigpO1xuICAgIHNlbmRSZXNwb25zZShudWxsKTtcbiAgICByZXR1cm47XG59KTtcbmNvbnN0IGhhbmRsZUluc2VydCA9IChtc2cpID0+IGluc2VydERhdGEobXNnLCAoKSA9PiBvcGVuVXJsKCkpO1xuY29uc3QgaW5zZXJ0RGF0YSA9IChtc2csIGNhbGxCYWNrKSA9PiBzdG9yYWdlLmdldChzdG9yZSwgcmVzcG9uc2UgPT4ge1xuICAgIGNvbnN0IHJlc3VsdHMgPSByZXNwb25zZVtzdG9yZV07XG4gICAgY29uc3QgcGF5bG9hZCA9IG1zZy5wYXlsb2FkO1xuICAgIGNvbnN0IG1ldGEgPSBwYXlsb2FkLm1ldGFkYXRhO1xuICAgIGxldCBta3QgPSByZXN1bHRzLmZpbmQoeCA9PiBlcXVhbHNNYXJrZXQoeCwgbWV0YSkpO1xuICAgIGlmIChta3QucGVyaW9kb0luaWNpYWwgPT09IG1ldGEucGVyaW9kb0luaWNpYWwpIHtcbiAgICAgICAgbWt0LmRhZG9zRW1wcmVzYUF0dWFsID0gcGF5bG9hZC50YWJsZURhdGE7XG4gICAgICAgIG1rdC5idXNjb3VEYWRvc0VtcHJBdHVhbCA9IHRydWU7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBta3QuZGFkb3NFbXByZXNhQW5vUGFzc2FkbyA9IHBheWxvYWQudGFibGVEYXRhO1xuICAgICAgICBta3QuYnVzY291RGFkb3NFbXByUGFzc2FkbyA9IHRydWU7XG4gICAgfVxuICAgIGNvbnN0IG5ld1ZhbHVlcyA9IFsuLi5yZXN1bHRzLmZpbHRlcih4ID0+ICFlcXVhbHNNYXJrZXQoeCwgbWV0YSkpLCBta3RdO1xuICAgIHN0b3JhZ2Uuc2V0KHsgW3N0b3JlXTogbmV3VmFsdWVzIH0sIGNhbGxCYWNrKTtcbn0pO1xuY29uc3QgZXF1YWxzTWFya2V0ID0gKHNyYywgdG8pID0+IHtcbiAgICBjb25zdCBjcmVhdGVIYXNoID0gKGxzdCkgPT4gbHN0LnNvcnQoKGEsIGIpID0+IGEgLSBiKS5qb2luKFwiLFwiKTtcbiAgICByZXR1cm4gY3JlYXRlSGFzaChzcmMuaWRSYW1vcykgPT09IGNyZWF0ZUhhc2godG8uaWRSYW1vcyk7XG59O1xuY29uc3QgZ2V0RGF0YVRvRXhwb3J0ID0gKG1zZywgc2VuZFJlc3BvbnNlKSA9PiBzdG9yYWdlLmdldChzdG9yZSwgcmVzcG9uc2UgPT4ge1xuICAgIGNvbnN0IGxzdCA9IHJlc3BvbnNlW3N0b3JlXTtcbiAgICBjb25zdCBoYXNUb0RvID0gbHN0ICYmICEhbHN0LmZpbmQoeCA9PiAheC5idXNjb3VEYWRvc0VtcHJBdHVhbCB8fCAheC5idXNjb3VEYWRvc0VtcHJQYXNzYWRvKTtcbiAgICBpZiAoaGFzVG9Ebykge1xuICAgICAgICBzZW5kUmVzcG9uc2UobnVsbCk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2VuZFJlc3BvbnNlKGxzdCk7XG59KTtcbmNvbnN0IGNsZWFuU3RvcmFnZUFuZEdvVG9BeGFTaXRlID0gKCkgPT4gY2xlYW5TdG9yYWdlKCgpID0+IG9wZW5VcmwodXJsQXhhKSk7XG5jb25zdCBjbGVhblN0b3JhZ2UgPSAoY2FsbEJhY2sgPSAoKSA9PiB7IH0pID0+IHN0b3JhZ2UucmVtb3ZlKHN0b3JlLCBjYWxsQmFjayk7XG5jb25zdCB1cGRhdGVDb25maWdzID0gKGNmZywgY2FsbEJhY2spID0+IHN0b3JhZ2Uuc2V0KHsgW3N0b3JlQ29uZmlnXTogY2ZnIH0sIGNhbGxCYWNrKTtcbmNvbnN0IGhhbmRsZVVwZGF0ZUNvbmZpZ3MgPSAobXNnLCBzZW5kcmVzcG9uc2UpID0+IHVwZGF0ZUNvbmZpZ3MobXNnLnBheWxvYWQsIHNlbmRyZXNwb25zZSk7XG5jb25zdCBnZXRBZ2dyZWdhdGVkQ29tcGFuaWVzID0gKG1zZywgc2VuZFJlcG9uc2UpID0+IGdldENvbmZpZ3MoY29uZmlncyA9PiBzZW5kUmVwb25zZShjb25maWdzLmFnZ3JlZ2F0ZWRDb21wYW5pZXMpKTtcbmNvbnN0IGhhbmRsZXJHZXRDb25maWdzID0gKG1zZywgc2VuZFJlc3BvbnNlKSA9PiBnZXRDb25maWdzKHNlbmRSZXNwb25zZSk7XG5jb25zdCBnZXRDb25maWdzID0gKGNhbGxiYWNrKSA9PiBzdG9yYWdlLmdldChzdG9yZUNvbmZpZywgcmVzcG9uc2UgPT4ge1xuICAgIHZhciBjb25maWdzID0gcmVzcG9uc2Vbc3RvcmVDb25maWddO1xuICAgIGlmICghY29uZmlncykge1xuICAgICAgICBzZXR1cENvbmZpZ3MoKCkgPT4gZ2V0Q29uZmlncyhjYWxsYmFjaykpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNhbGxiYWNrKGNvbmZpZ3MpO1xufSk7XG5jb25zdCBoYW5kbGVGaW5pc2hpZXNFeHBvcnQgPSAobXNnLCBzZW5kUmVzcG9uc2UpID0+IGdldENvbmZpZ3MoY2ZncyA9PiB7XG4gICAgaWYgKCFjZmdzLmdlbmVyYXRlUmF3RGF0YSkge1xuICAgICAgICBjbGVhblN0b3JhZ2VBbmRHb1RvQXhhU2l0ZSgpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIG9wZW5VcmwodXJsQXhhKTtcbn0pO1xuY29uc3QgcmVzZXRDb25maWdzID0gKG1zZywgc2VuZFJlc3BvbnNlKSA9PiBzZXR1cENvbmZpZ3Moc2VuZFJlc3BvbnNlKTtcbi8vdG9kbyBjb21wbGV0YXIgbGlzdGEgZGUgZ3J1cG9zIGVtcHJlc2FyaWFpc1xuY29uc3Qgc2V0dXBDb25maWdzID0gY2FsbGJhY2sgPT4ge1xuICAgIGNvbnN0IGlkRHB2YXQgPSA1ODg7XG4gICAgY29uc3QgbWt0cyA9IFtcbiAgICAgICAgeyBub21lOiBcIkF2aWF0aW9uXCIsIGlkUmFtb3M6IFsxNTI4LCAxNTM1LCAxNTM3LCAxNTk3XSB9LFxuICAgICAgICB7IG5vbWU6IFwiRmluYW5jaWFsIExpbmVzXCIsIGlkUmFtb3M6IFszMTAsIDM3OF0gfSxcbiAgICAgICAgeyBub21lOiBcIkNhcmdvXCIsIGlkUmFtb3M6IFs2MjEsIDYyMiwgNjMyLCA2MzgsIDY1MiwgNjU0LCA2NTUsIDY1NiwgNjU4XSB9LFxuICAgICAgICB7IG5vbWU6IFwiQ2FzdWFsdHlcIiwgaWRSYW1vczogWzM1MV0gfSxcbiAgICAgICAgeyBub21lOiBcIkNvbnN0cnVjdGlvblwiLCBpZFJhbW9zOiBbMTY3XSB9LFxuICAgICAgICB7IG5vbWU6IFwiRW52aXJvbm1lbnRhbFwiLCBpZFJhbW9zOiBbMzEzXSB9LFxuICAgICAgICB7IG5vbWU6IFwiUG9ydFwiLCBpZFJhbW9zOiBbMTQxN10gfSxcbiAgICAgICAgLy8gICAgICAgIHsgbm9tZTogXCJQcm9wZXJ0eVwiLCBpZFJhbW9zOiBbMTk2LCAxNDEsIDExOF0gfSxcbiAgICAgICAgeyBub21lOiBcIlBSQ0JcIiwgaWRSYW1vczogWzc0OCwgNzQ5XSB9LFxuICAgICAgICB7IG5vbWU6IFwiUHJvcGVydHkgUk5PXCIsIGlkUmFtb3M6IFsxOTZdIH0sXG4gICAgICAgIHsgbm9tZTogXCJQcm9wZXJ0eSBDb21wci4gRW1wLlwiLCBpZFJhbW9zOiBbMTE4XSB9LFxuICAgICAgICB7IG5vbWU6IFwiUHJvcGVydHkgVG90YWxcIiwgaWRSYW1vczogWzE5NiwgMTQxLCAxMThdIH0sXG4gICAgICAgIHsgbm9tZTogXCJNYXJpbmUgSHVsbFwiLCBpZFJhbW9zOiBbMTQzM10gfSxcbiAgICAgICAgeyBub21lOiBcImN5YmVyXCIsIGlkUmFtb3M6IFszMjddIH0sXG4gICAgICAgIHsgbm9tZTogXCJTdXJldHlcIiwgaWRSYW1vczogWzc3NSwgNzc2XSB9LFxuICAgICAgICB7IG5vbWU6IFwiQ29uZG9tw61uaW9cIiwgaWRSYW1vczogWzExNl0gfSxcbiAgICAgICAgeyBub21lOiBcIk1pc2NlbGxhbmVvdXNcIiwgaWRSYW1vczogWzE3MV0gfSxcbiAgICBdO1xuICAgIGNvbnN0IGFsbElkcyA9IG1rdHMubWFwKHggPT4geC5pZFJhbW9zKS5yZWR1Y2UoKGFsbCwgaXRlbSkgPT4gWy4uLmFsbCwgLi4uaXRlbV0sIFtdKTtcbiAgICB1cGRhdGVDb25maWdzKHtcbiAgICAgICAgbWFya2V0czogW1xuICAgICAgICAgICAgLi4ubWt0cyxcbiAgICAgICAgICAgIHsgbm9tZTogXCJUb3RhbCBzZW0gRFBWQVRcIiwgaWRSYW1vczogYWxsSWRzIH0sXG4gICAgICAgICAgICB7IG5vbWU6IFwiRFBWQVRcIiwgaWRSYW1vczogW2lkRHB2YXRdIH0sXG4gICAgICAgICAgICB7IG5vbWU6IFwiVG90YWwgY29tIERQVkFUXCIsIGlkUmFtb3M6IFsuLi5hbGxJZHMsIGlkRHB2YXRdIH0sXG4gICAgICAgIF0sXG4gICAgICAgIGFnZ3JlZ2F0ZWRDb21wYW5pZXM6IFtcbiAgICAgICAgICAgIHsgbm9tZTogXCJNQVBGUkUgQkFOQ08gRE8gQlJBU0lMXCIsIGlkRW1wcmVzYXM6IFs2MjM4LCA2MjExLCA2Nzg1LCA2MTgxLCAzMjg5XSB9LFxuICAgICAgICAgICAgeyBub21lOiBcIlBPUlRPIFNFR1VST1wiLCBpZEVtcHJlc2FzOiBbNTg4NiwgNTM1NSwgMzE4MiwgNjAzM10gfSxcbiAgICAgICAgICAgIHsgbm9tZTogXCJaVVJJQ0hcIiwgaWRFbXByZXNhczogWzU0OTUsIDU5NDEsIDY1NjRdIH0sXG4gICAgICAgICAgICB7IG5vbWU6IFwiSERJXCIsIGlkRW1wcmVzYXM6IFsxNTcxLCA2NTcyXSB9LFxuICAgICAgICAgICAgeyBub21lOiBcIkFYQVwiLCBpZEVtcHJlc2FzOiBbMTQzMSwgMjg1MiwgNjY5Nl0sIGlzQXhhOiB0cnVlIH0sXG4gICAgICAgICAgICB7IG5vbWU6IFwiQlJBREVTQ09cIiwgaWRFbXByZXNhczogWzUzMTIsIDU1MzNdIH0sXG4gICAgICAgICAgICB7IG5vbWU6IFwiQ09GQUNFXCIsIGlkRW1wcmVzYXM6IFs2MzM1XSB9LFxuICAgICAgICAgICAgeyBub21lOiBcIklDQVRVXCIsIGlkRW1wcmVzYXM6IFs1MTQyLCA1NjU3XSB9LFxuICAgICAgICAgICAgeyBub21lOiBcIlNBRlJBXCIsIGlkRW1wcmVzYXM6IFsxNjI3LCA5OTM4XSB9LFxuICAgICAgICAgICAgeyBub21lOiBcIkFMRkFcIiwgaWRFbXByZXNhczogWzY0NjcsIDI4OTVdIH0sXG4gICAgICAgICAgICB7IG5vbWU6IFwiQ0FQRU1JU0FcIiwgaWRFbXByZXNhczogWzQyNTEsIDE3NDFdIH0sXG4gICAgICAgICAgICB7IG5vbWU6IFwiQ09NUFJFVlwiLCBpZEVtcHJlc2FzOiBbMTkzNywgMjg3OV0gfSxcbiAgICAgICAgICAgIHsgbm9tZTogXCJJTlZFU1RQUkVWXCIsIGlkRW1wcmVzYXM6IFs2OTIxLCA2MTczXSB9LFxuICAgICAgICBdLFxuICAgICAgICBnZW5lcmF0ZVJhd0RhdGE6IGZhbHNlLFxuICAgICAgICBuYW1lRXhwb3J0ZWRGaWxlOiBcIlRlbXBsYXRlIGNvbXBhcmF0aXZvIGRlIG1lcmNhZG9cIlxuICAgIH0sIGNhbGxiYWNrKTtcbn07XG4iXSwic291cmNlUm9vdCI6IiJ9