/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1];
/******/ 		var executeModules = data[2];
/******/
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fulfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fulfilled = false;
/******/ 			}
/******/ 			if(fulfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 	// Promise = chunk loading, 0 = chunk loaded
/******/ 	var installedChunks = {
/******/ 		"background": 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push(["./src/background.ts","vendor"]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/background.ts":
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const types_1 = __webpack_require__(/*! ./types */ "./src/types.ts");
const queryInfo = {
    active: true,
    currentWindow: true
};
const store = "SusepData";
const storeConfig = "ConfigAxaCrowler";
const storage = chrome.storage.local;
const urlSusep = "http://www2.susep.gov.br/menuestatistica/SES/premiosesinistros.aspx?id=54";
const urlAxa = "https://www.axa.com.br/";
let tabId = 0;
let count = 0;
chrome.runtime.onMessage.addListener((msg, info, sendResponse) => {
    const lstHandlers = [
        { type: types_1.msgType.startProcess, handler: startProcess },
        { type: types_1.msgType.insertData, handler: handleInsert },
        { type: types_1.msgType.getNext, handler: getNext },
        { type: types_1.msgType.getCrowlerIsActive, handler: getIsActive },
        { type: types_1.msgType.getDataToExport, handler: getDataToExport },
        { type: types_1.msgType.getAggregatedCompanies, handler: getAggregatedCompanies },
        { type: types_1.msgType.finishiesExportSpreadSheet, handler: handleFinishiesExport },
        { type: types_1.msgType.cleanStorage, handler: cleanStorageAndGoToAxaSite },
        { type: types_1.msgType.getConfigs, handler: handlerGetConfigs },
        { type: types_1.msgType.saveConfigs, handler: handleUpdateConfigs },
        { type: types_1.msgType.resetConfigs, handler: resetConfigs },
    ];
    const { handler } = lstHandlers.find(x => x.type === msg.type) || { handler: null };
    if (!handler)
        return;
    handler(msg, sendResponse);
    return true;
});
const updateCounter = (n = null) => {
    count = n || count - 1;
    if (count === -1)
        count = null;
    const labelCount = (count || "").toString();
    chrome.browserAction.setBadgeText({ text: labelCount });
};
const startProcess = (msg) => getConfigs(configs => {
    const { periodoFinal, periodoInicial } = msg.payload;
    updateCounter(configs.markets.length * 2);
    cleanStorage();
    storage.set({ [store]: configs.markets.map(x => ({
            nome: x.nome,
            idRamos: x.idRamos,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
            dadosEmpresaAnoPassado: [],
            dadosEmpresaAtual: [],
            buscouDadosEmprAtual: false,
            buscouDadosEmprPassado: false
        })) });
    chrome.tabs.query(queryInfo, tabs => {
        tabId = tabs[0].id;
        openUrl();
    });
});
const getIsActive = (msg, sendResponse) => storage.get(store, response => {
    const storeData = response[store];
    sendResponse(!!storeData);
});
const openUrl = (url = urlSusep) => chrome.tabs.update(tabId, { url });
const getLastYear = (mkt) => ({
    nome: mkt.nome,
    idRamos: mkt.idRamos,
    periodoInicial: mkt.periodoInicial - 100,
    periodoFinal: mkt.periodoFinal - 100
});
const getNext = (msg, sendResponse) => storage.get(store, response => {
    const results = response[store];
    if (!results) {
        sendResponse(null);
        return;
    }
    const nextActualYear = results.find(x => !x.buscouDadosEmprAtual);
    if (!!nextActualYear) {
        updateCounter();
        sendResponse(nextActualYear);
        return;
    }
    const nextLastYear = results.find(x => !x.buscouDadosEmprPassado);
    if (!!nextLastYear) {
        updateCounter();
        sendResponse(getLastYear(nextLastYear));
        return;
    }
    updateCounter();
    sendResponse(null);
    return;
});
const handleInsert = (msg) => insertData(msg, () => openUrl());
const insertData = (msg, callBack) => storage.get(store, response => {
    const results = response[store];
    const payload = msg.payload;
    const meta = payload.metadata;
    let mkt = results.find(x => equalsMarket(x, meta));
    if (mkt.periodoInicial === meta.periodoInicial) {
        mkt.dadosEmpresaAtual = payload.tableData;
        mkt.totalSinistridade = meta.totalSinistridade;
        mkt.buscouDadosEmprAtual = true;
    }
    else {
        mkt.dadosEmpresaAnoPassado = payload.tableData;
        mkt.buscouDadosEmprPassado = true;
    }
    const newValues = [...results.filter(x => !equalsMarket(x, meta)), mkt];
    storage.set({ [store]: newValues }, callBack);
});
const equalsMarket = (src, to) => {
    const distinctFilter = (ramo, index, lstRamos) => lstRamos.indexOf(ramo) === index;
    const createHash = (lst) => lst.sort((a, b) => a - b).filter(distinctFilter).join(",");
    return createHash(src.idRamos) === createHash(to.idRamos);
};
const getDataToExport = (msg, sendResponse) => storage.get(store, response => {
    const lst = response[store];
    const hasToDo = lst && !!lst.find(x => !x.buscouDadosEmprAtual || !x.buscouDadosEmprPassado);
    if (hasToDo) {
        sendResponse(null);
        return;
    }
    sendResponse(lst);
});
const cleanStorageAndGoToAxaSite = () => cleanStorage(() => openUrl(urlAxa));
const cleanStorage = (callBack = () => { }) => storage.remove(store, callBack);
const updateConfigs = (cfg, callBack) => storage.set({ [storeConfig]: cfg }, callBack);
const handleUpdateConfigs = (msg, sendresponse) => updateConfigs(msg.payload, sendresponse);
const getAggregatedCompanies = (msg, sendReponse) => getConfigs(configs => sendReponse(configs.aggregatedCompanies));
const handlerGetConfigs = (msg, sendResponse) => getConfigs(sendResponse);
const getConfigs = (callback) => storage.get(storeConfig, response => {
    var configs = response[storeConfig];
    if (!configs) {
        setupConfigs(() => getConfigs(callback));
        return;
    }
    callback(configs);
});
const handleFinishiesExport = (msg, sendResponse) => getConfigs(cfgs => {
    if (!cfgs.generateRawData) {
        cleanStorageAndGoToAxaSite();
        return;
    }
    openUrl(urlAxa);
});
const resetConfigs = (msg, sendResponse) => setupConfigs(sendResponse);
//todo completar lista de grupos empresariais
const setupConfigs = callback => {
    const idDpvat = 588;
    const mkts = [
        { nome: "Aviation", idRamos: [1528, 1535, 1537, 1597] },
        { nome: "Financial Lines", idRamos: [310, 378] },
        { nome: "Cargo", idRamos: [621, 622, 632, 638, 652, 654, 655, 656, 658] },
        { nome: "Casualty", idRamos: [351] },
        { nome: "Construction", idRamos: [167] },
        { nome: "Environmental", idRamos: [313] },
        { nome: "Port", idRamos: [1417] },
        //        { nome: "Property", idRamos: [196, 141, 118] },
        { nome: "PRCB", idRamos: [748, 749] },
        { nome: "Property RNO", idRamos: [196] },
        { nome: "Property Compr. Emp.", idRamos: [118] },
        { nome: "Property Total", idRamos: [196, 141, 118] },
        { nome: "Marine Hull", idRamos: [1433] },
        { nome: "cyber", idRamos: [327] },
        { nome: "Surety", idRamos: [775, 776] },
        { nome: "Condomínio", idRamos: [116] },
        { nome: "Miscellaneous", idRamos: [171] },
    ];
    const allIds = mkts
        .map(x => x.idRamos)
        .reduce((all, item) => [...all, ...item], []);
    updateConfigs({
        markets: [
            ...mkts,
            { nome: "Total sem DPVAT", idRamos: allIds },
            { nome: "DPVAT", idRamos: [idDpvat] },
            { nome: "Total com DPVAT", idRamos: [...allIds, idDpvat] },
        ],
        aggregatedCompanies: [
            { nome: "MAPFRE BANCO DO BRASIL", idEmpresas: [6238, 6211, 6785, 6181, 3289] },
            { nome: "PORTO SEGURO", idEmpresas: [5886, 5355, 3182, 6033] },
            { nome: "ZURICH", idEmpresas: [5495, 5941, 6564] },
            { nome: "HDI", idEmpresas: [1571, 6572] },
            { nome: "AXA", idEmpresas: [1431, 2852, 6696], isAxa: true },
            { nome: "BRADESCO", idEmpresas: [5312, 5533] },
            { nome: "COFACE", idEmpresas: [6335] },
            { nome: "ICATU", idEmpresas: [5142, 5657] },
            { nome: "SAFRA", idEmpresas: [1627, 9938] },
            { nome: "ALFA", idEmpresas: [6467, 2895] },
            { nome: "CAPEMISA", idEmpresas: [4251, 1741] },
            { nome: "COMPREV", idEmpresas: [1937, 2879] },
            { nome: "INVESTPREV", idEmpresas: [6921, 6173] },
        ],
        generateRawData: false,
        nameExportedFile: "Template comparativo de mercado"
    }, callback);
};


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2JhY2tncm91bmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZ0JBQVEsb0JBQW9CO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQWlCLDRCQUE0QjtBQUM3QztBQUNBO0FBQ0EsMEJBQWtCLDJCQUEyQjtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxrREFBMEMsZ0NBQWdDO0FBQzFFO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZ0VBQXdELGtCQUFrQjtBQUMxRTtBQUNBLHlEQUFpRCxjQUFjO0FBQy9EOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBeUMsaUNBQWlDO0FBQzFFLHdIQUFnSCxtQkFBbUIsRUFBRTtBQUNySTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLG1DQUEyQiwwQkFBMEIsRUFBRTtBQUN2RCx5Q0FBaUMsZUFBZTtBQUNoRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw4REFBc0QsK0RBQStEOztBQUVySDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQWdCLHVCQUF1QjtBQUN2Qzs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUN0SmE7QUFDYiw4Q0FBOEMsY0FBYztBQUM1RCxnQkFBZ0IsbUJBQU8sQ0FBQywrQkFBUztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsNERBQTREO0FBQ3JFLFNBQVMsMERBQTBEO0FBQ25FLFNBQVMsa0RBQWtEO0FBQzNELFNBQVMsaUVBQWlFO0FBQzFFLFNBQVMsa0VBQWtFO0FBQzNFLFNBQVMsZ0ZBQWdGO0FBQ3pGLFNBQVMsbUZBQW1GO0FBQzVGLFNBQVMsMEVBQTBFO0FBQ25GLFNBQVMsK0RBQStEO0FBQ3hFLFNBQVMsa0VBQWtFO0FBQzNFLFNBQVMsNERBQTREO0FBQ3JFO0FBQ0EsV0FBVyxVQUFVLGtEQUFrRDtBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLG1CQUFtQjtBQUMxRDtBQUNBO0FBQ0EsV0FBVywrQkFBK0I7QUFDMUM7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxJQUFJO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0QsK0RBQStELE1BQU07QUFDckU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIscUJBQXFCO0FBQ3RDLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBLHdDQUF3QyxFQUFFO0FBQzFDLHNEQUFzRCxxQkFBcUI7QUFDM0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLHNEQUFzRDtBQUMvRCxTQUFTLCtDQUErQztBQUN4RCxTQUFTLHdFQUF3RTtBQUNqRixTQUFTLG1DQUFtQztBQUM1QyxTQUFTLHVDQUF1QztBQUNoRCxTQUFTLHdDQUF3QztBQUNqRCxTQUFTLGdDQUFnQztBQUN6QyxtQkFBbUIsNkNBQTZDO0FBQ2hFLFNBQVMsb0NBQW9DO0FBQzdDLFNBQVMsdUNBQXVDO0FBQ2hELFNBQVMsK0NBQStDO0FBQ3hELFNBQVMsbURBQW1EO0FBQzVELFNBQVMsdUNBQXVDO0FBQ2hELFNBQVMsZ0NBQWdDO0FBQ3pDLFNBQVMsc0NBQXNDO0FBQy9DLFNBQVMscUNBQXFDO0FBQzlDLFNBQVMsd0NBQXdDO0FBQ2pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYSwyQ0FBMkM7QUFDeEQsYUFBYSxvQ0FBb0M7QUFDakQsYUFBYSx5REFBeUQ7QUFDdEU7QUFDQTtBQUNBLGFBQWEsNkVBQTZFO0FBQzFGLGFBQWEsNkRBQTZEO0FBQzFFLGFBQWEsaURBQWlEO0FBQzlELGFBQWEsd0NBQXdDO0FBQ3JELGFBQWEsMkRBQTJEO0FBQ3hFLGFBQWEsNkNBQTZDO0FBQzFELGFBQWEscUNBQXFDO0FBQ2xELGFBQWEsMENBQTBDO0FBQ3ZELGFBQWEsMENBQTBDO0FBQ3ZELGFBQWEseUNBQXlDO0FBQ3RELGFBQWEsNkNBQTZDO0FBQzFELGFBQWEsNENBQTRDO0FBQ3pELGFBQWEsK0NBQStDO0FBQzVEO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCIsImZpbGUiOiJiYWNrZ3JvdW5kLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gaW5zdGFsbCBhIEpTT05QIGNhbGxiYWNrIGZvciBjaHVuayBsb2FkaW5nXG4gXHRmdW5jdGlvbiB3ZWJwYWNrSnNvbnBDYWxsYmFjayhkYXRhKSB7XG4gXHRcdHZhciBjaHVua0lkcyA9IGRhdGFbMF07XG4gXHRcdHZhciBtb3JlTW9kdWxlcyA9IGRhdGFbMV07XG4gXHRcdHZhciBleGVjdXRlTW9kdWxlcyA9IGRhdGFbMl07XG5cbiBcdFx0Ly8gYWRkIFwibW9yZU1vZHVsZXNcIiB0byB0aGUgbW9kdWxlcyBvYmplY3QsXG4gXHRcdC8vIHRoZW4gZmxhZyBhbGwgXCJjaHVua0lkc1wiIGFzIGxvYWRlZCBhbmQgZmlyZSBjYWxsYmFja1xuIFx0XHR2YXIgbW9kdWxlSWQsIGNodW5rSWQsIGkgPSAwLCByZXNvbHZlcyA9IFtdO1xuIFx0XHRmb3IoO2kgPCBjaHVua0lkcy5sZW5ndGg7IGkrKykge1xuIFx0XHRcdGNodW5rSWQgPSBjaHVua0lkc1tpXTtcbiBcdFx0XHRpZihpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0pIHtcbiBcdFx0XHRcdHJlc29sdmVzLnB1c2goaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdWzBdKTtcbiBcdFx0XHR9XG4gXHRcdFx0aW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdID0gMDtcbiBcdFx0fVxuIFx0XHRmb3IobW9kdWxlSWQgaW4gbW9yZU1vZHVsZXMpIHtcbiBcdFx0XHRpZihPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwobW9yZU1vZHVsZXMsIG1vZHVsZUlkKSkge1xuIFx0XHRcdFx0bW9kdWxlc1ttb2R1bGVJZF0gPSBtb3JlTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdFx0fVxuIFx0XHR9XG4gXHRcdGlmKHBhcmVudEpzb25wRnVuY3Rpb24pIHBhcmVudEpzb25wRnVuY3Rpb24oZGF0YSk7XG5cbiBcdFx0d2hpbGUocmVzb2x2ZXMubGVuZ3RoKSB7XG4gXHRcdFx0cmVzb2x2ZXMuc2hpZnQoKSgpO1xuIFx0XHR9XG5cbiBcdFx0Ly8gYWRkIGVudHJ5IG1vZHVsZXMgZnJvbSBsb2FkZWQgY2h1bmsgdG8gZGVmZXJyZWQgbGlzdFxuIFx0XHRkZWZlcnJlZE1vZHVsZXMucHVzaC5hcHBseShkZWZlcnJlZE1vZHVsZXMsIGV4ZWN1dGVNb2R1bGVzIHx8IFtdKTtcblxuIFx0XHQvLyBydW4gZGVmZXJyZWQgbW9kdWxlcyB3aGVuIGFsbCBjaHVua3MgcmVhZHlcbiBcdFx0cmV0dXJuIGNoZWNrRGVmZXJyZWRNb2R1bGVzKCk7XG4gXHR9O1xuIFx0ZnVuY3Rpb24gY2hlY2tEZWZlcnJlZE1vZHVsZXMoKSB7XG4gXHRcdHZhciByZXN1bHQ7XG4gXHRcdGZvcih2YXIgaSA9IDA7IGkgPCBkZWZlcnJlZE1vZHVsZXMubGVuZ3RoOyBpKyspIHtcbiBcdFx0XHR2YXIgZGVmZXJyZWRNb2R1bGUgPSBkZWZlcnJlZE1vZHVsZXNbaV07XG4gXHRcdFx0dmFyIGZ1bGZpbGxlZCA9IHRydWU7XG4gXHRcdFx0Zm9yKHZhciBqID0gMTsgaiA8IGRlZmVycmVkTW9kdWxlLmxlbmd0aDsgaisrKSB7XG4gXHRcdFx0XHR2YXIgZGVwSWQgPSBkZWZlcnJlZE1vZHVsZVtqXTtcbiBcdFx0XHRcdGlmKGluc3RhbGxlZENodW5rc1tkZXBJZF0gIT09IDApIGZ1bGZpbGxlZCA9IGZhbHNlO1xuIFx0XHRcdH1cbiBcdFx0XHRpZihmdWxmaWxsZWQpIHtcbiBcdFx0XHRcdGRlZmVycmVkTW9kdWxlcy5zcGxpY2UoaS0tLCAxKTtcbiBcdFx0XHRcdHJlc3VsdCA9IF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gZGVmZXJyZWRNb2R1bGVbMF0pO1xuIFx0XHRcdH1cbiBcdFx0fVxuIFx0XHRyZXR1cm4gcmVzdWx0O1xuIFx0fVxuXG4gXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBvYmplY3QgdG8gc3RvcmUgbG9hZGVkIGFuZCBsb2FkaW5nIGNodW5rc1xuIFx0Ly8gdW5kZWZpbmVkID0gY2h1bmsgbm90IGxvYWRlZCwgbnVsbCA9IGNodW5rIHByZWxvYWRlZC9wcmVmZXRjaGVkXG4gXHQvLyBQcm9taXNlID0gY2h1bmsgbG9hZGluZywgMCA9IGNodW5rIGxvYWRlZFxuIFx0dmFyIGluc3RhbGxlZENodW5rcyA9IHtcbiBcdFx0XCJiYWNrZ3JvdW5kXCI6IDBcbiBcdH07XG5cbiBcdHZhciBkZWZlcnJlZE1vZHVsZXMgPSBbXTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuIFx0dmFyIGpzb25wQXJyYXkgPSB3aW5kb3dbXCJ3ZWJwYWNrSnNvbnBcIl0gPSB3aW5kb3dbXCJ3ZWJwYWNrSnNvbnBcIl0gfHwgW107XG4gXHR2YXIgb2xkSnNvbnBGdW5jdGlvbiA9IGpzb25wQXJyYXkucHVzaC5iaW5kKGpzb25wQXJyYXkpO1xuIFx0anNvbnBBcnJheS5wdXNoID0gd2VicGFja0pzb25wQ2FsbGJhY2s7XG4gXHRqc29ucEFycmF5ID0ganNvbnBBcnJheS5zbGljZSgpO1xuIFx0Zm9yKHZhciBpID0gMDsgaSA8IGpzb25wQXJyYXkubGVuZ3RoOyBpKyspIHdlYnBhY2tKc29ucENhbGxiYWNrKGpzb25wQXJyYXlbaV0pO1xuIFx0dmFyIHBhcmVudEpzb25wRnVuY3Rpb24gPSBvbGRKc29ucEZ1bmN0aW9uO1xuXG5cbiBcdC8vIGFkZCBlbnRyeSBtb2R1bGUgdG8gZGVmZXJyZWQgbGlzdFxuIFx0ZGVmZXJyZWRNb2R1bGVzLnB1c2goW1wiLi9zcmMvYmFja2dyb3VuZC50c1wiLFwidmVuZG9yXCJdKTtcbiBcdC8vIHJ1biBkZWZlcnJlZCBtb2R1bGVzIHdoZW4gcmVhZHlcbiBcdHJldHVybiBjaGVja0RlZmVycmVkTW9kdWxlcygpO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5jb25zdCB0eXBlc18xID0gcmVxdWlyZShcIi4vdHlwZXNcIik7XG5jb25zdCBxdWVyeUluZm8gPSB7XG4gICAgYWN0aXZlOiB0cnVlLFxuICAgIGN1cnJlbnRXaW5kb3c6IHRydWVcbn07XG5jb25zdCBzdG9yZSA9IFwiU3VzZXBEYXRhXCI7XG5jb25zdCBzdG9yZUNvbmZpZyA9IFwiQ29uZmlnQXhhQ3Jvd2xlclwiO1xuY29uc3Qgc3RvcmFnZSA9IGNocm9tZS5zdG9yYWdlLmxvY2FsO1xuY29uc3QgdXJsU3VzZXAgPSBcImh0dHA6Ly93d3cyLnN1c2VwLmdvdi5ici9tZW51ZXN0YXRpc3RpY2EvU0VTL3ByZW1pb3Nlc2luaXN0cm9zLmFzcHg/aWQ9NTRcIjtcbmNvbnN0IHVybEF4YSA9IFwiaHR0cHM6Ly93d3cuYXhhLmNvbS5ici9cIjtcbmxldCB0YWJJZCA9IDA7XG5sZXQgY291bnQgPSAwO1xuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2csIGluZm8sIHNlbmRSZXNwb25zZSkgPT4ge1xuICAgIGNvbnN0IGxzdEhhbmRsZXJzID0gW1xuICAgICAgICB7IHR5cGU6IHR5cGVzXzEubXNnVHlwZS5zdGFydFByb2Nlc3MsIGhhbmRsZXI6IHN0YXJ0UHJvY2VzcyB9LFxuICAgICAgICB7IHR5cGU6IHR5cGVzXzEubXNnVHlwZS5pbnNlcnREYXRhLCBoYW5kbGVyOiBoYW5kbGVJbnNlcnQgfSxcbiAgICAgICAgeyB0eXBlOiB0eXBlc18xLm1zZ1R5cGUuZ2V0TmV4dCwgaGFuZGxlcjogZ2V0TmV4dCB9LFxuICAgICAgICB7IHR5cGU6IHR5cGVzXzEubXNnVHlwZS5nZXRDcm93bGVySXNBY3RpdmUsIGhhbmRsZXI6IGdldElzQWN0aXZlIH0sXG4gICAgICAgIHsgdHlwZTogdHlwZXNfMS5tc2dUeXBlLmdldERhdGFUb0V4cG9ydCwgaGFuZGxlcjogZ2V0RGF0YVRvRXhwb3J0IH0sXG4gICAgICAgIHsgdHlwZTogdHlwZXNfMS5tc2dUeXBlLmdldEFnZ3JlZ2F0ZWRDb21wYW5pZXMsIGhhbmRsZXI6IGdldEFnZ3JlZ2F0ZWRDb21wYW5pZXMgfSxcbiAgICAgICAgeyB0eXBlOiB0eXBlc18xLm1zZ1R5cGUuZmluaXNoaWVzRXhwb3J0U3ByZWFkU2hlZXQsIGhhbmRsZXI6IGhhbmRsZUZpbmlzaGllc0V4cG9ydCB9LFxuICAgICAgICB7IHR5cGU6IHR5cGVzXzEubXNnVHlwZS5jbGVhblN0b3JhZ2UsIGhhbmRsZXI6IGNsZWFuU3RvcmFnZUFuZEdvVG9BeGFTaXRlIH0sXG4gICAgICAgIHsgdHlwZTogdHlwZXNfMS5tc2dUeXBlLmdldENvbmZpZ3MsIGhhbmRsZXI6IGhhbmRsZXJHZXRDb25maWdzIH0sXG4gICAgICAgIHsgdHlwZTogdHlwZXNfMS5tc2dUeXBlLnNhdmVDb25maWdzLCBoYW5kbGVyOiBoYW5kbGVVcGRhdGVDb25maWdzIH0sXG4gICAgICAgIHsgdHlwZTogdHlwZXNfMS5tc2dUeXBlLnJlc2V0Q29uZmlncywgaGFuZGxlcjogcmVzZXRDb25maWdzIH0sXG4gICAgXTtcbiAgICBjb25zdCB7IGhhbmRsZXIgfSA9IGxzdEhhbmRsZXJzLmZpbmQoeCA9PiB4LnR5cGUgPT09IG1zZy50eXBlKSB8fCB7IGhhbmRsZXI6IG51bGwgfTtcbiAgICBpZiAoIWhhbmRsZXIpXG4gICAgICAgIHJldHVybjtcbiAgICBoYW5kbGVyKG1zZywgc2VuZFJlc3BvbnNlKTtcbiAgICByZXR1cm4gdHJ1ZTtcbn0pO1xuY29uc3QgdXBkYXRlQ291bnRlciA9IChuID0gbnVsbCkgPT4ge1xuICAgIGNvdW50ID0gbiB8fCBjb3VudCAtIDE7XG4gICAgaWYgKGNvdW50ID09PSAtMSlcbiAgICAgICAgY291bnQgPSBudWxsO1xuICAgIGNvbnN0IGxhYmVsQ291bnQgPSAoY291bnQgfHwgXCJcIikudG9TdHJpbmcoKTtcbiAgICBjaHJvbWUuYnJvd3NlckFjdGlvbi5zZXRCYWRnZVRleHQoeyB0ZXh0OiBsYWJlbENvdW50IH0pO1xufTtcbmNvbnN0IHN0YXJ0UHJvY2VzcyA9IChtc2cpID0+IGdldENvbmZpZ3MoY29uZmlncyA9PiB7XG4gICAgY29uc3QgeyBwZXJpb2RvRmluYWwsIHBlcmlvZG9JbmljaWFsIH0gPSBtc2cucGF5bG9hZDtcbiAgICB1cGRhdGVDb3VudGVyKGNvbmZpZ3MubWFya2V0cy5sZW5ndGggKiAyKTtcbiAgICBjbGVhblN0b3JhZ2UoKTtcbiAgICBzdG9yYWdlLnNldCh7IFtzdG9yZV06IGNvbmZpZ3MubWFya2V0cy5tYXAoeCA9PiAoe1xuICAgICAgICAgICAgbm9tZTogeC5ub21lLFxuICAgICAgICAgICAgaWRSYW1vczogeC5pZFJhbW9zLFxuICAgICAgICAgICAgcGVyaW9kb0luaWNpYWw6IHBlcmlvZG9JbmljaWFsLFxuICAgICAgICAgICAgcGVyaW9kb0ZpbmFsOiBwZXJpb2RvRmluYWwsXG4gICAgICAgICAgICBkYWRvc0VtcHJlc2FBbm9QYXNzYWRvOiBbXSxcbiAgICAgICAgICAgIGRhZG9zRW1wcmVzYUF0dWFsOiBbXSxcbiAgICAgICAgICAgIGJ1c2NvdURhZG9zRW1wckF0dWFsOiBmYWxzZSxcbiAgICAgICAgICAgIGJ1c2NvdURhZG9zRW1wclBhc3NhZG86IGZhbHNlXG4gICAgICAgIH0pKSB9KTtcbiAgICBjaHJvbWUudGFicy5xdWVyeShxdWVyeUluZm8sIHRhYnMgPT4ge1xuICAgICAgICB0YWJJZCA9IHRhYnNbMF0uaWQ7XG4gICAgICAgIG9wZW5VcmwoKTtcbiAgICB9KTtcbn0pO1xuY29uc3QgZ2V0SXNBY3RpdmUgPSAobXNnLCBzZW5kUmVzcG9uc2UpID0+IHN0b3JhZ2UuZ2V0KHN0b3JlLCByZXNwb25zZSA9PiB7XG4gICAgY29uc3Qgc3RvcmVEYXRhID0gcmVzcG9uc2Vbc3RvcmVdO1xuICAgIHNlbmRSZXNwb25zZSghIXN0b3JlRGF0YSk7XG59KTtcbmNvbnN0IG9wZW5VcmwgPSAodXJsID0gdXJsU3VzZXApID0+IGNocm9tZS50YWJzLnVwZGF0ZSh0YWJJZCwgeyB1cmwgfSk7XG5jb25zdCBnZXRMYXN0WWVhciA9IChta3QpID0+ICh7XG4gICAgbm9tZTogbWt0Lm5vbWUsXG4gICAgaWRSYW1vczogbWt0LmlkUmFtb3MsXG4gICAgcGVyaW9kb0luaWNpYWw6IG1rdC5wZXJpb2RvSW5pY2lhbCAtIDEwMCxcbiAgICBwZXJpb2RvRmluYWw6IG1rdC5wZXJpb2RvRmluYWwgLSAxMDBcbn0pO1xuY29uc3QgZ2V0TmV4dCA9IChtc2csIHNlbmRSZXNwb25zZSkgPT4gc3RvcmFnZS5nZXQoc3RvcmUsIHJlc3BvbnNlID0+IHtcbiAgICBjb25zdCByZXN1bHRzID0gcmVzcG9uc2Vbc3RvcmVdO1xuICAgIGlmICghcmVzdWx0cykge1xuICAgICAgICBzZW5kUmVzcG9uc2UobnVsbCk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgbmV4dEFjdHVhbFllYXIgPSByZXN1bHRzLmZpbmQoeCA9PiAheC5idXNjb3VEYWRvc0VtcHJBdHVhbCk7XG4gICAgaWYgKCEhbmV4dEFjdHVhbFllYXIpIHtcbiAgICAgICAgdXBkYXRlQ291bnRlcigpO1xuICAgICAgICBzZW5kUmVzcG9uc2UobmV4dEFjdHVhbFllYXIpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG5leHRMYXN0WWVhciA9IHJlc3VsdHMuZmluZCh4ID0+ICF4LmJ1c2NvdURhZG9zRW1wclBhc3NhZG8pO1xuICAgIGlmICghIW5leHRMYXN0WWVhcikge1xuICAgICAgICB1cGRhdGVDb3VudGVyKCk7XG4gICAgICAgIHNlbmRSZXNwb25zZShnZXRMYXN0WWVhcihuZXh0TGFzdFllYXIpKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB1cGRhdGVDb3VudGVyKCk7XG4gICAgc2VuZFJlc3BvbnNlKG51bGwpO1xuICAgIHJldHVybjtcbn0pO1xuY29uc3QgaGFuZGxlSW5zZXJ0ID0gKG1zZykgPT4gaW5zZXJ0RGF0YShtc2csICgpID0+IG9wZW5VcmwoKSk7XG5jb25zdCBpbnNlcnREYXRhID0gKG1zZywgY2FsbEJhY2spID0+IHN0b3JhZ2UuZ2V0KHN0b3JlLCByZXNwb25zZSA9PiB7XG4gICAgY29uc3QgcmVzdWx0cyA9IHJlc3BvbnNlW3N0b3JlXTtcbiAgICBjb25zdCBwYXlsb2FkID0gbXNnLnBheWxvYWQ7XG4gICAgY29uc3QgbWV0YSA9IHBheWxvYWQubWV0YWRhdGE7XG4gICAgbGV0IG1rdCA9IHJlc3VsdHMuZmluZCh4ID0+IGVxdWFsc01hcmtldCh4LCBtZXRhKSk7XG4gICAgaWYgKG1rdC5wZXJpb2RvSW5pY2lhbCA9PT0gbWV0YS5wZXJpb2RvSW5pY2lhbCkge1xuICAgICAgICBta3QuZGFkb3NFbXByZXNhQXR1YWwgPSBwYXlsb2FkLnRhYmxlRGF0YTtcbiAgICAgICAgbWt0LnRvdGFsU2luaXN0cmlkYWRlID0gbWV0YS50b3RhbFNpbmlzdHJpZGFkZTtcbiAgICAgICAgbWt0LmJ1c2NvdURhZG9zRW1wckF0dWFsID0gdHJ1ZTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIG1rdC5kYWRvc0VtcHJlc2FBbm9QYXNzYWRvID0gcGF5bG9hZC50YWJsZURhdGE7XG4gICAgICAgIG1rdC5idXNjb3VEYWRvc0VtcHJQYXNzYWRvID0gdHJ1ZTtcbiAgICB9XG4gICAgY29uc3QgbmV3VmFsdWVzID0gWy4uLnJlc3VsdHMuZmlsdGVyKHggPT4gIWVxdWFsc01hcmtldCh4LCBtZXRhKSksIG1rdF07XG4gICAgc3RvcmFnZS5zZXQoeyBbc3RvcmVdOiBuZXdWYWx1ZXMgfSwgY2FsbEJhY2spO1xufSk7XG5jb25zdCBlcXVhbHNNYXJrZXQgPSAoc3JjLCB0bykgPT4ge1xuICAgIGNvbnN0IGRpc3RpbmN0RmlsdGVyID0gKHJhbW8sIGluZGV4LCBsc3RSYW1vcykgPT4gbHN0UmFtb3MuaW5kZXhPZihyYW1vKSA9PT0gaW5kZXg7XG4gICAgY29uc3QgY3JlYXRlSGFzaCA9IChsc3QpID0+IGxzdC5zb3J0KChhLCBiKSA9PiBhIC0gYikuZmlsdGVyKGRpc3RpbmN0RmlsdGVyKS5qb2luKFwiLFwiKTtcbiAgICByZXR1cm4gY3JlYXRlSGFzaChzcmMuaWRSYW1vcykgPT09IGNyZWF0ZUhhc2godG8uaWRSYW1vcyk7XG59O1xuY29uc3QgZ2V0RGF0YVRvRXhwb3J0ID0gKG1zZywgc2VuZFJlc3BvbnNlKSA9PiBzdG9yYWdlLmdldChzdG9yZSwgcmVzcG9uc2UgPT4ge1xuICAgIGNvbnN0IGxzdCA9IHJlc3BvbnNlW3N0b3JlXTtcbiAgICBjb25zdCBoYXNUb0RvID0gbHN0ICYmICEhbHN0LmZpbmQoeCA9PiAheC5idXNjb3VEYWRvc0VtcHJBdHVhbCB8fCAheC5idXNjb3VEYWRvc0VtcHJQYXNzYWRvKTtcbiAgICBpZiAoaGFzVG9Ebykge1xuICAgICAgICBzZW5kUmVzcG9uc2UobnVsbCk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2VuZFJlc3BvbnNlKGxzdCk7XG59KTtcbmNvbnN0IGNsZWFuU3RvcmFnZUFuZEdvVG9BeGFTaXRlID0gKCkgPT4gY2xlYW5TdG9yYWdlKCgpID0+IG9wZW5VcmwodXJsQXhhKSk7XG5jb25zdCBjbGVhblN0b3JhZ2UgPSAoY2FsbEJhY2sgPSAoKSA9PiB7IH0pID0+IHN0b3JhZ2UucmVtb3ZlKHN0b3JlLCBjYWxsQmFjayk7XG5jb25zdCB1cGRhdGVDb25maWdzID0gKGNmZywgY2FsbEJhY2spID0+IHN0b3JhZ2Uuc2V0KHsgW3N0b3JlQ29uZmlnXTogY2ZnIH0sIGNhbGxCYWNrKTtcbmNvbnN0IGhhbmRsZVVwZGF0ZUNvbmZpZ3MgPSAobXNnLCBzZW5kcmVzcG9uc2UpID0+IHVwZGF0ZUNvbmZpZ3MobXNnLnBheWxvYWQsIHNlbmRyZXNwb25zZSk7XG5jb25zdCBnZXRBZ2dyZWdhdGVkQ29tcGFuaWVzID0gKG1zZywgc2VuZFJlcG9uc2UpID0+IGdldENvbmZpZ3MoY29uZmlncyA9PiBzZW5kUmVwb25zZShjb25maWdzLmFnZ3JlZ2F0ZWRDb21wYW5pZXMpKTtcbmNvbnN0IGhhbmRsZXJHZXRDb25maWdzID0gKG1zZywgc2VuZFJlc3BvbnNlKSA9PiBnZXRDb25maWdzKHNlbmRSZXNwb25zZSk7XG5jb25zdCBnZXRDb25maWdzID0gKGNhbGxiYWNrKSA9PiBzdG9yYWdlLmdldChzdG9yZUNvbmZpZywgcmVzcG9uc2UgPT4ge1xuICAgIHZhciBjb25maWdzID0gcmVzcG9uc2Vbc3RvcmVDb25maWddO1xuICAgIGlmICghY29uZmlncykge1xuICAgICAgICBzZXR1cENvbmZpZ3MoKCkgPT4gZ2V0Q29uZmlncyhjYWxsYmFjaykpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNhbGxiYWNrKGNvbmZpZ3MpO1xufSk7XG5jb25zdCBoYW5kbGVGaW5pc2hpZXNFeHBvcnQgPSAobXNnLCBzZW5kUmVzcG9uc2UpID0+IGdldENvbmZpZ3MoY2ZncyA9PiB7XG4gICAgaWYgKCFjZmdzLmdlbmVyYXRlUmF3RGF0YSkge1xuICAgICAgICBjbGVhblN0b3JhZ2VBbmRHb1RvQXhhU2l0ZSgpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIG9wZW5VcmwodXJsQXhhKTtcbn0pO1xuY29uc3QgcmVzZXRDb25maWdzID0gKG1zZywgc2VuZFJlc3BvbnNlKSA9PiBzZXR1cENvbmZpZ3Moc2VuZFJlc3BvbnNlKTtcbi8vdG9kbyBjb21wbGV0YXIgbGlzdGEgZGUgZ3J1cG9zIGVtcHJlc2FyaWFpc1xuY29uc3Qgc2V0dXBDb25maWdzID0gY2FsbGJhY2sgPT4ge1xuICAgIGNvbnN0IGlkRHB2YXQgPSA1ODg7XG4gICAgY29uc3QgbWt0cyA9IFtcbiAgICAgICAgeyBub21lOiBcIkF2aWF0aW9uXCIsIGlkUmFtb3M6IFsxNTI4LCAxNTM1LCAxNTM3LCAxNTk3XSB9LFxuICAgICAgICB7IG5vbWU6IFwiRmluYW5jaWFsIExpbmVzXCIsIGlkUmFtb3M6IFszMTAsIDM3OF0gfSxcbiAgICAgICAgeyBub21lOiBcIkNhcmdvXCIsIGlkUmFtb3M6IFs2MjEsIDYyMiwgNjMyLCA2MzgsIDY1MiwgNjU0LCA2NTUsIDY1NiwgNjU4XSB9LFxuICAgICAgICB7IG5vbWU6IFwiQ2FzdWFsdHlcIiwgaWRSYW1vczogWzM1MV0gfSxcbiAgICAgICAgeyBub21lOiBcIkNvbnN0cnVjdGlvblwiLCBpZFJhbW9zOiBbMTY3XSB9LFxuICAgICAgICB7IG5vbWU6IFwiRW52aXJvbm1lbnRhbFwiLCBpZFJhbW9zOiBbMzEzXSB9LFxuICAgICAgICB7IG5vbWU6IFwiUG9ydFwiLCBpZFJhbW9zOiBbMTQxN10gfSxcbiAgICAgICAgLy8gICAgICAgIHsgbm9tZTogXCJQcm9wZXJ0eVwiLCBpZFJhbW9zOiBbMTk2LCAxNDEsIDExOF0gfSxcbiAgICAgICAgeyBub21lOiBcIlBSQ0JcIiwgaWRSYW1vczogWzc0OCwgNzQ5XSB9LFxuICAgICAgICB7IG5vbWU6IFwiUHJvcGVydHkgUk5PXCIsIGlkUmFtb3M6IFsxOTZdIH0sXG4gICAgICAgIHsgbm9tZTogXCJQcm9wZXJ0eSBDb21wci4gRW1wLlwiLCBpZFJhbW9zOiBbMTE4XSB9LFxuICAgICAgICB7IG5vbWU6IFwiUHJvcGVydHkgVG90YWxcIiwgaWRSYW1vczogWzE5NiwgMTQxLCAxMThdIH0sXG4gICAgICAgIHsgbm9tZTogXCJNYXJpbmUgSHVsbFwiLCBpZFJhbW9zOiBbMTQzM10gfSxcbiAgICAgICAgeyBub21lOiBcImN5YmVyXCIsIGlkUmFtb3M6IFszMjddIH0sXG4gICAgICAgIHsgbm9tZTogXCJTdXJldHlcIiwgaWRSYW1vczogWzc3NSwgNzc2XSB9LFxuICAgICAgICB7IG5vbWU6IFwiQ29uZG9tw61uaW9cIiwgaWRSYW1vczogWzExNl0gfSxcbiAgICAgICAgeyBub21lOiBcIk1pc2NlbGxhbmVvdXNcIiwgaWRSYW1vczogWzE3MV0gfSxcbiAgICBdO1xuICAgIGNvbnN0IGFsbElkcyA9IG1rdHNcbiAgICAgICAgLm1hcCh4ID0+IHguaWRSYW1vcylcbiAgICAgICAgLnJlZHVjZSgoYWxsLCBpdGVtKSA9PiBbLi4uYWxsLCAuLi5pdGVtXSwgW10pO1xuICAgIHVwZGF0ZUNvbmZpZ3Moe1xuICAgICAgICBtYXJrZXRzOiBbXG4gICAgICAgICAgICAuLi5ta3RzLFxuICAgICAgICAgICAgeyBub21lOiBcIlRvdGFsIHNlbSBEUFZBVFwiLCBpZFJhbW9zOiBhbGxJZHMgfSxcbiAgICAgICAgICAgIHsgbm9tZTogXCJEUFZBVFwiLCBpZFJhbW9zOiBbaWREcHZhdF0gfSxcbiAgICAgICAgICAgIHsgbm9tZTogXCJUb3RhbCBjb20gRFBWQVRcIiwgaWRSYW1vczogWy4uLmFsbElkcywgaWREcHZhdF0gfSxcbiAgICAgICAgXSxcbiAgICAgICAgYWdncmVnYXRlZENvbXBhbmllczogW1xuICAgICAgICAgICAgeyBub21lOiBcIk1BUEZSRSBCQU5DTyBETyBCUkFTSUxcIiwgaWRFbXByZXNhczogWzYyMzgsIDYyMTEsIDY3ODUsIDYxODEsIDMyODldIH0sXG4gICAgICAgICAgICB7IG5vbWU6IFwiUE9SVE8gU0VHVVJPXCIsIGlkRW1wcmVzYXM6IFs1ODg2LCA1MzU1LCAzMTgyLCA2MDMzXSB9LFxuICAgICAgICAgICAgeyBub21lOiBcIlpVUklDSFwiLCBpZEVtcHJlc2FzOiBbNTQ5NSwgNTk0MSwgNjU2NF0gfSxcbiAgICAgICAgICAgIHsgbm9tZTogXCJIRElcIiwgaWRFbXByZXNhczogWzE1NzEsIDY1NzJdIH0sXG4gICAgICAgICAgICB7IG5vbWU6IFwiQVhBXCIsIGlkRW1wcmVzYXM6IFsxNDMxLCAyODUyLCA2Njk2XSwgaXNBeGE6IHRydWUgfSxcbiAgICAgICAgICAgIHsgbm9tZTogXCJCUkFERVNDT1wiLCBpZEVtcHJlc2FzOiBbNTMxMiwgNTUzM10gfSxcbiAgICAgICAgICAgIHsgbm9tZTogXCJDT0ZBQ0VcIiwgaWRFbXByZXNhczogWzYzMzVdIH0sXG4gICAgICAgICAgICB7IG5vbWU6IFwiSUNBVFVcIiwgaWRFbXByZXNhczogWzUxNDIsIDU2NTddIH0sXG4gICAgICAgICAgICB7IG5vbWU6IFwiU0FGUkFcIiwgaWRFbXByZXNhczogWzE2MjcsIDk5MzhdIH0sXG4gICAgICAgICAgICB7IG5vbWU6IFwiQUxGQVwiLCBpZEVtcHJlc2FzOiBbNjQ2NywgMjg5NV0gfSxcbiAgICAgICAgICAgIHsgbm9tZTogXCJDQVBFTUlTQVwiLCBpZEVtcHJlc2FzOiBbNDI1MSwgMTc0MV0gfSxcbiAgICAgICAgICAgIHsgbm9tZTogXCJDT01QUkVWXCIsIGlkRW1wcmVzYXM6IFsxOTM3LCAyODc5XSB9LFxuICAgICAgICAgICAgeyBub21lOiBcIklOVkVTVFBSRVZcIiwgaWRFbXByZXNhczogWzY5MjEsIDYxNzNdIH0sXG4gICAgICAgIF0sXG4gICAgICAgIGdlbmVyYXRlUmF3RGF0YTogZmFsc2UsXG4gICAgICAgIG5hbWVFeHBvcnRlZEZpbGU6IFwiVGVtcGxhdGUgY29tcGFyYXRpdm8gZGUgbWVyY2Fkb1wiXG4gICAgfSwgY2FsbGJhY2spO1xufTtcbiJdLCJzb3VyY2VSb290IjoiIn0=