/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1];
/******/ 		var executeModules = data[2];
/******/
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fulfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fulfilled = false;
/******/ 			}
/******/ 			if(fulfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 	// Promise = chunk loading, 0 = chunk loaded
/******/ 	var installedChunks = {
/******/ 		"contentGenerateRawSheet": 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push(["./src/contentGenerateRawSheet.ts","vendor"]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/contentGenerateRawSheet.ts":
/*!****************************************!*\
  !*** ./src/contentGenerateRawSheet.ts ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const types_1 = __webpack_require__(/*! ./types */ "./src/types.ts");
const ExcelJS = __webpack_require__(/*! exceljs/dist/es5/exceljs.browser */ "./node_modules/exceljs/dist/es5/exceljs.browser.js");
const messager = chrome.runtime.sendMessage;
const decimalFormatting = "#,##0.##";
const intFormatting = "#,##0";
const skipTextColumns = 2;
const startProccess = (allData) => {
    if (!allData)
        return;
    const start = (cfgs) => {
        if (!cfgs.generateRawData)
            return;
        generateRawSpreadSheet(allData, cfgs);
    };
    messager({ type: types_1.msgType.getConfigs }, start);
};
messager({ type: types_1.msgType.getDataToExport }, startProccess);
const border = {
    top: { style: 'thin' },
    left: { style: 'thin' },
    bottom: { style: 'thin' },
    right: { style: 'thin' }
};
const sitylingTitle = row => {
    row.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "1C5E55" }
    };
    row.font = {
        name: 'Verdana',
        size: 11,
        bold: true,
        color: { argb: "ffffff" }
    };
    row.border = border;
};
const alignLeft = cell => cell.alignment = {
    vertical: 'top',
    horizontal: 'left'
};
const alignCenter = cell => cell.alignment = {
    vertical: 'top',
    horizontal: 'center'
};
const generateRawSpreadSheet = (data, cfgs) => {
    var workbook = new ExcelJS.Workbook();
    workbook.creator = "Kevyn Pinheiro Klava";
    workbook.created = new Date();
    workbook.properties.date1904 = true;
    workbook.views = [
        {
            x: 0, y: 0, width: 10000, height: 20000,
            firstSheet: 0, activeTab: 1, visibility: 'visible'
        }
    ];
    const metadata = [
        { prop: "dadosEmpresaAtual", stampYear: 0 },
        { prop: "dadosEmpresaAnoPassado", stampYear: 1 }
    ];
    data.forEach(mkt => metadata.forEach(meta => {
        const labelSheet = `DB ${mkt.nome} ${(mkt.periodoFinal - (meta.stampYear * 100)).toString().substr(0, 4)}`;
        generateSheets(workbook, mkt[meta.prop], labelSheet);
    }));
    downloadFile(workbook, cfgs.nameExportedFile);
};
const hasDecimalPlaces = (number) => !!(number % 1);
const generateSheets = (workbook, data, titleSheet) => {
    const sheet = workbook.addWorksheet(titleSheet, {
        views: [{ showGridLines: true }]
    });
    generateTitle(sheet);
    generateSubTitle(sheet, data);
    data.forEach((dt, index) => {
        const row = sheet.addRow(dt);
        row.border = border;
        row.font = {
            name: 'Verdana',
            size: 11,
            color: { argb: "333333" }
        };
        if (!!(index % 2))
            row.fill = {
                type: "pattern",
                pattern: "solid",
                fgColor: { argb: "E3EAEB" }
            };
        Array.from({ length: skipTextColumns }, (x, i) => alignLeft(row.getCell(i + 1)));
        Object.keys(dt).slice(skipTextColumns).forEach((prop, i) => {
            const cell = row.getCell(i + 1 + skipTextColumns);
            cell.numFmt = hasDecimalPlaces(dt[prop]) ? decimalFormatting : intFormatting;
        });
    });
};
const generateTitle = (sheet) => {
    const titles = [
        { prop: "idSusep", titulo: `Código SUSEP`, width: 17.29 },
        { prop: "empresa", titulo: `Empresa`, width: 72 },
        { prop: "premioEmitido", titulo: `Prêmio Emitido ³`, width: 20.57 },
        { prop: "premioGanho", titulo: `Prêmio Ganho ¹`, width: 19.29 },
        { prop: "despesaResseguro", titulo: `Despesa com Resseguro ³`, width: 32 },
        { prop: "sinistroOcorrido", titulo: `Sinistro Ocorrido ³`, width: 22.43 },
        { prop: "receitaResseguro", titulo: `Receita com Resseguro ³`, width: 30.71 },
        { prop: "despesaComercial", titulo: `Despesa Comercial`, width: 23.14 },
        { prop: "sinistralidade", titulo: `Sinistralidade ¹`, width: 18.57 },
        { prop: "rvne", titulo: `RVNE ³`, width: 14.57 },
    ];
    sheet.columns = titles.map(title => ({
        header: title.titulo,
        key: title.prop,
        width: title.width,
        style: {
            font: {
                name: 'Verdana',
                size: 11,
            }
        }
    }));
    const rowTitle = sheet.getRow(1);
    alignCenter(rowTitle);
    sitylingTitle(rowTitle);
};
const generateSubTitle = (sheet, data) => {
    const alphabet = "CDEFGHIJKLMNOPQRSUVWXYZ";
    const totals = [
        { titulo: `` },
        { titulo: `Totais` },
        ...Array.from({ length: sheet.columns.length - skipTextColumns }, z => ({ titulo: "", sum: true }))
    ];
    const totalRows = sheet.addRow([...totals].map(a => a.titulo));
    alignCenter(totalRows.getCell(2));
    sitylingTitle(totalRows);
    totals.slice(skipTextColumns).forEach((x, i) => {
        const idCol = i + 1 + skipTextColumns;
        const cell = totalRows.getCell(idCol);
        const prop = sheet.getColumn(idCol).key;
        const sum = data.reduce((a, b) => a + b[prop], 0);
        /*        cell.value = {
                    formula: `=SUM(${alphabet[i]}${skipTextColumns + 1}:${alphabet[i]}${data.length + 2})`,
                    result: sum
                } */
        cell.numFmt = hasDecimalPlaces(sum) ? decimalFormatting : intFormatting;
    });
};
const downloadFile = (workbook, fileName) => workbook.xlsx.writeBuffer()
    .then(res => {
    const dataFile = new Blob([res], { type: "octet/stream" });
    const url = window.URL.createObjectURL(dataFile);
    const a = document.createElement("a");
    a.setAttribute("style", "display: none");
    a.href = url;
    a.download = `Database ${fileName}.xlsx`;
    a.click();
    window.URL.revokeObjectURL(url);
});


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbnRlbnRHZW5lcmF0ZVJhd1NoZWV0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGdCQUFRLG9CQUFvQjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUFpQiw0QkFBNEI7QUFDN0M7QUFDQTtBQUNBLDBCQUFrQiwyQkFBMkI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7QUFHQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0Esa0RBQTBDLGdDQUFnQztBQUMxRTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGdFQUF3RCxrQkFBa0I7QUFDMUU7QUFDQSx5REFBaUQsY0FBYztBQUMvRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQXlDLGlDQUFpQztBQUMxRSx3SEFBZ0gsbUJBQW1CLEVBQUU7QUFDckk7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxtQ0FBMkIsMEJBQTBCLEVBQUU7QUFDdkQseUNBQWlDLGVBQWU7QUFDaEQ7QUFDQTtBQUNBOztBQUVBO0FBQ0EsOERBQXNELCtEQUErRDs7QUFFckg7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUFnQix1QkFBdUI7QUFDdkM7OztBQUdBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDdEphO0FBQ2IsOENBQThDLGNBQWM7QUFDNUQsZ0JBQWdCLG1CQUFPLENBQUMsK0JBQVM7QUFDakMsZ0JBQWdCLG1CQUFPLENBQUMsNEZBQWtDO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWMsbUNBQW1DO0FBQ2pEO0FBQ0EsVUFBVSx3Q0FBd0M7QUFDbEQ7QUFDQSxVQUFVLGdCQUFnQjtBQUMxQixXQUFXLGdCQUFnQjtBQUMzQixhQUFhLGdCQUFnQjtBQUM3QixZQUFZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQjtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0JBQWdCO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLDBDQUEwQztBQUNuRCxTQUFTO0FBQ1Q7QUFDQTtBQUNBLGlDQUFpQyxTQUFTLEdBQUcsb0VBQW9FO0FBQ2pIO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsc0JBQXNCO0FBQ3ZDLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQSxvQkFBb0IsMEJBQTBCO0FBQzlDO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsU0FBUyx3REFBd0Q7QUFDakUsU0FBUyxnREFBZ0Q7QUFDekQsU0FBUyxrRUFBa0U7QUFDM0UsU0FBUyw4REFBOEQ7QUFDdkUsU0FBUyx5RUFBeUU7QUFDbEYsU0FBUyx3RUFBd0U7QUFDakYsU0FBUyw0RUFBNEU7QUFDckYsU0FBUyxzRUFBc0U7QUFDL0UsU0FBUyxtRUFBbUU7QUFDNUUsU0FBUywrQ0FBK0M7QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsYUFBYTtBQUN0QixTQUFTLG1CQUFtQjtBQUM1Qix1QkFBdUIsaURBQWlELFNBQVMsd0JBQXdCO0FBQ3pHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDLFlBQVksRUFBRSxvQkFBb0IsR0FBRyxZQUFZLEVBQUUsZ0JBQWdCO0FBQ3hHO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQyx1QkFBdUI7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkIsU0FBUztBQUN0QztBQUNBO0FBQ0EsQ0FBQyIsImZpbGUiOiJjb250ZW50R2VuZXJhdGVSYXdTaGVldC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIGluc3RhbGwgYSBKU09OUCBjYWxsYmFjayBmb3IgY2h1bmsgbG9hZGluZ1xuIFx0ZnVuY3Rpb24gd2VicGFja0pzb25wQ2FsbGJhY2soZGF0YSkge1xuIFx0XHR2YXIgY2h1bmtJZHMgPSBkYXRhWzBdO1xuIFx0XHR2YXIgbW9yZU1vZHVsZXMgPSBkYXRhWzFdO1xuIFx0XHR2YXIgZXhlY3V0ZU1vZHVsZXMgPSBkYXRhWzJdO1xuXG4gXHRcdC8vIGFkZCBcIm1vcmVNb2R1bGVzXCIgdG8gdGhlIG1vZHVsZXMgb2JqZWN0LFxuIFx0XHQvLyB0aGVuIGZsYWcgYWxsIFwiY2h1bmtJZHNcIiBhcyBsb2FkZWQgYW5kIGZpcmUgY2FsbGJhY2tcbiBcdFx0dmFyIG1vZHVsZUlkLCBjaHVua0lkLCBpID0gMCwgcmVzb2x2ZXMgPSBbXTtcbiBcdFx0Zm9yKDtpIDwgY2h1bmtJZHMubGVuZ3RoOyBpKyspIHtcbiBcdFx0XHRjaHVua0lkID0gY2h1bmtJZHNbaV07XG4gXHRcdFx0aWYoaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdKSB7XG4gXHRcdFx0XHRyZXNvbHZlcy5wdXNoKGluc3RhbGxlZENodW5rc1tjaHVua0lkXVswXSk7XG4gXHRcdFx0fVxuIFx0XHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkXSA9IDA7XG4gXHRcdH1cbiBcdFx0Zm9yKG1vZHVsZUlkIGluIG1vcmVNb2R1bGVzKSB7XG4gXHRcdFx0aWYoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1vcmVNb2R1bGVzLCBtb2R1bGVJZCkpIHtcbiBcdFx0XHRcdG1vZHVsZXNbbW9kdWxlSWRdID0gbW9yZU1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHRcdH1cbiBcdFx0fVxuIFx0XHRpZihwYXJlbnRKc29ucEZ1bmN0aW9uKSBwYXJlbnRKc29ucEZ1bmN0aW9uKGRhdGEpO1xuXG4gXHRcdHdoaWxlKHJlc29sdmVzLmxlbmd0aCkge1xuIFx0XHRcdHJlc29sdmVzLnNoaWZ0KCkoKTtcbiBcdFx0fVxuXG4gXHRcdC8vIGFkZCBlbnRyeSBtb2R1bGVzIGZyb20gbG9hZGVkIGNodW5rIHRvIGRlZmVycmVkIGxpc3RcbiBcdFx0ZGVmZXJyZWRNb2R1bGVzLnB1c2guYXBwbHkoZGVmZXJyZWRNb2R1bGVzLCBleGVjdXRlTW9kdWxlcyB8fCBbXSk7XG5cbiBcdFx0Ly8gcnVuIGRlZmVycmVkIG1vZHVsZXMgd2hlbiBhbGwgY2h1bmtzIHJlYWR5XG4gXHRcdHJldHVybiBjaGVja0RlZmVycmVkTW9kdWxlcygpO1xuIFx0fTtcbiBcdGZ1bmN0aW9uIGNoZWNrRGVmZXJyZWRNb2R1bGVzKCkge1xuIFx0XHR2YXIgcmVzdWx0O1xuIFx0XHRmb3IodmFyIGkgPSAwOyBpIDwgZGVmZXJyZWRNb2R1bGVzLmxlbmd0aDsgaSsrKSB7XG4gXHRcdFx0dmFyIGRlZmVycmVkTW9kdWxlID0gZGVmZXJyZWRNb2R1bGVzW2ldO1xuIFx0XHRcdHZhciBmdWxmaWxsZWQgPSB0cnVlO1xuIFx0XHRcdGZvcih2YXIgaiA9IDE7IGogPCBkZWZlcnJlZE1vZHVsZS5sZW5ndGg7IGorKykge1xuIFx0XHRcdFx0dmFyIGRlcElkID0gZGVmZXJyZWRNb2R1bGVbal07XG4gXHRcdFx0XHRpZihpbnN0YWxsZWRDaHVua3NbZGVwSWRdICE9PSAwKSBmdWxmaWxsZWQgPSBmYWxzZTtcbiBcdFx0XHR9XG4gXHRcdFx0aWYoZnVsZmlsbGVkKSB7XG4gXHRcdFx0XHRkZWZlcnJlZE1vZHVsZXMuc3BsaWNlKGktLSwgMSk7XG4gXHRcdFx0XHRyZXN1bHQgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IGRlZmVycmVkTW9kdWxlWzBdKTtcbiBcdFx0XHR9XG4gXHRcdH1cbiBcdFx0cmV0dXJuIHJlc3VsdDtcbiBcdH1cblxuIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gb2JqZWN0IHRvIHN0b3JlIGxvYWRlZCBhbmQgbG9hZGluZyBjaHVua3NcbiBcdC8vIHVuZGVmaW5lZCA9IGNodW5rIG5vdCBsb2FkZWQsIG51bGwgPSBjaHVuayBwcmVsb2FkZWQvcHJlZmV0Y2hlZFxuIFx0Ly8gUHJvbWlzZSA9IGNodW5rIGxvYWRpbmcsIDAgPSBjaHVuayBsb2FkZWRcbiBcdHZhciBpbnN0YWxsZWRDaHVua3MgPSB7XG4gXHRcdFwiY29udGVudEdlbmVyYXRlUmF3U2hlZXRcIjogMFxuIFx0fTtcblxuIFx0dmFyIGRlZmVycmVkTW9kdWxlcyA9IFtdO1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG4gXHR2YXIganNvbnBBcnJheSA9IHdpbmRvd1tcIndlYnBhY2tKc29ucFwiXSA9IHdpbmRvd1tcIndlYnBhY2tKc29ucFwiXSB8fCBbXTtcbiBcdHZhciBvbGRKc29ucEZ1bmN0aW9uID0ganNvbnBBcnJheS5wdXNoLmJpbmQoanNvbnBBcnJheSk7XG4gXHRqc29ucEFycmF5LnB1c2ggPSB3ZWJwYWNrSnNvbnBDYWxsYmFjaztcbiBcdGpzb25wQXJyYXkgPSBqc29ucEFycmF5LnNsaWNlKCk7XG4gXHRmb3IodmFyIGkgPSAwOyBpIDwganNvbnBBcnJheS5sZW5ndGg7IGkrKykgd2VicGFja0pzb25wQ2FsbGJhY2soanNvbnBBcnJheVtpXSk7XG4gXHR2YXIgcGFyZW50SnNvbnBGdW5jdGlvbiA9IG9sZEpzb25wRnVuY3Rpb247XG5cblxuIFx0Ly8gYWRkIGVudHJ5IG1vZHVsZSB0byBkZWZlcnJlZCBsaXN0XG4gXHRkZWZlcnJlZE1vZHVsZXMucHVzaChbXCIuL3NyYy9jb250ZW50R2VuZXJhdGVSYXdTaGVldC50c1wiLFwidmVuZG9yXCJdKTtcbiBcdC8vIHJ1biBkZWZlcnJlZCBtb2R1bGVzIHdoZW4gcmVhZHlcbiBcdHJldHVybiBjaGVja0RlZmVycmVkTW9kdWxlcygpO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5jb25zdCB0eXBlc18xID0gcmVxdWlyZShcIi4vdHlwZXNcIik7XG5jb25zdCBFeGNlbEpTID0gcmVxdWlyZShcImV4Y2VsanMvZGlzdC9lczUvZXhjZWxqcy5icm93c2VyXCIpO1xuY29uc3QgbWVzc2FnZXIgPSBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZTtcbmNvbnN0IGRlY2ltYWxGb3JtYXR0aW5nID0gXCIjLCMjMC4jI1wiO1xuY29uc3QgaW50Rm9ybWF0dGluZyA9IFwiIywjIzBcIjtcbmNvbnN0IHNraXBUZXh0Q29sdW1ucyA9IDI7XG5jb25zdCBzdGFydFByb2NjZXNzID0gKGFsbERhdGEpID0+IHtcbiAgICBpZiAoIWFsbERhdGEpXG4gICAgICAgIHJldHVybjtcbiAgICBjb25zdCBzdGFydCA9IChjZmdzKSA9PiB7XG4gICAgICAgIGlmICghY2Zncy5nZW5lcmF0ZVJhd0RhdGEpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIGdlbmVyYXRlUmF3U3ByZWFkU2hlZXQoYWxsRGF0YSwgY2Zncyk7XG4gICAgfTtcbiAgICBtZXNzYWdlcih7IHR5cGU6IHR5cGVzXzEubXNnVHlwZS5nZXRDb25maWdzIH0sIHN0YXJ0KTtcbn07XG5tZXNzYWdlcih7IHR5cGU6IHR5cGVzXzEubXNnVHlwZS5nZXREYXRhVG9FeHBvcnQgfSwgc3RhcnRQcm9jY2Vzcyk7XG5jb25zdCBib3JkZXIgPSB7XG4gICAgdG9wOiB7IHN0eWxlOiAndGhpbicgfSxcbiAgICBsZWZ0OiB7IHN0eWxlOiAndGhpbicgfSxcbiAgICBib3R0b206IHsgc3R5bGU6ICd0aGluJyB9LFxuICAgIHJpZ2h0OiB7IHN0eWxlOiAndGhpbicgfVxufTtcbmNvbnN0IHNpdHlsaW5nVGl0bGUgPSByb3cgPT4ge1xuICAgIHJvdy5maWxsID0ge1xuICAgICAgICB0eXBlOiBcInBhdHRlcm5cIixcbiAgICAgICAgcGF0dGVybjogXCJzb2xpZFwiLFxuICAgICAgICBmZ0NvbG9yOiB7IGFyZ2I6IFwiMUM1RTU1XCIgfVxuICAgIH07XG4gICAgcm93LmZvbnQgPSB7XG4gICAgICAgIG5hbWU6ICdWZXJkYW5hJyxcbiAgICAgICAgc2l6ZTogMTEsXG4gICAgICAgIGJvbGQ6IHRydWUsXG4gICAgICAgIGNvbG9yOiB7IGFyZ2I6IFwiZmZmZmZmXCIgfVxuICAgIH07XG4gICAgcm93LmJvcmRlciA9IGJvcmRlcjtcbn07XG5jb25zdCBhbGlnbkxlZnQgPSBjZWxsID0+IGNlbGwuYWxpZ25tZW50ID0ge1xuICAgIHZlcnRpY2FsOiAndG9wJyxcbiAgICBob3Jpem9udGFsOiAnbGVmdCdcbn07XG5jb25zdCBhbGlnbkNlbnRlciA9IGNlbGwgPT4gY2VsbC5hbGlnbm1lbnQgPSB7XG4gICAgdmVydGljYWw6ICd0b3AnLFxuICAgIGhvcml6b250YWw6ICdjZW50ZXInXG59O1xuY29uc3QgZ2VuZXJhdGVSYXdTcHJlYWRTaGVldCA9IChkYXRhLCBjZmdzKSA9PiB7XG4gICAgdmFyIHdvcmtib29rID0gbmV3IEV4Y2VsSlMuV29ya2Jvb2soKTtcbiAgICB3b3JrYm9vay5jcmVhdG9yID0gXCJLZXZ5biBQaW5oZWlybyBLbGF2YVwiO1xuICAgIHdvcmtib29rLmNyZWF0ZWQgPSBuZXcgRGF0ZSgpO1xuICAgIHdvcmtib29rLnByb3BlcnRpZXMuZGF0ZTE5MDQgPSB0cnVlO1xuICAgIHdvcmtib29rLnZpZXdzID0gW1xuICAgICAgICB7XG4gICAgICAgICAgICB4OiAwLCB5OiAwLCB3aWR0aDogMTAwMDAsIGhlaWdodDogMjAwMDAsXG4gICAgICAgICAgICBmaXJzdFNoZWV0OiAwLCBhY3RpdmVUYWI6IDEsIHZpc2liaWxpdHk6ICd2aXNpYmxlJ1xuICAgICAgICB9XG4gICAgXTtcbiAgICBjb25zdCBtZXRhZGF0YSA9IFtcbiAgICAgICAgeyBwcm9wOiBcImRhZG9zRW1wcmVzYUF0dWFsXCIsIHN0YW1wWWVhcjogMCB9LFxuICAgICAgICB7IHByb3A6IFwiZGFkb3NFbXByZXNhQW5vUGFzc2Fkb1wiLCBzdGFtcFllYXI6IDEgfVxuICAgIF07XG4gICAgZGF0YS5mb3JFYWNoKG1rdCA9PiBtZXRhZGF0YS5mb3JFYWNoKG1ldGEgPT4ge1xuICAgICAgICBjb25zdCBsYWJlbFNoZWV0ID0gYERCICR7bWt0Lm5vbWV9ICR7KG1rdC5wZXJpb2RvRmluYWwgLSAobWV0YS5zdGFtcFllYXIgKiAxMDApKS50b1N0cmluZygpLnN1YnN0cigwLCA0KX1gO1xuICAgICAgICBnZW5lcmF0ZVNoZWV0cyh3b3JrYm9vaywgbWt0W21ldGEucHJvcF0sIGxhYmVsU2hlZXQpO1xuICAgIH0pKTtcbiAgICBkb3dubG9hZEZpbGUod29ya2Jvb2ssIGNmZ3MubmFtZUV4cG9ydGVkRmlsZSk7XG59O1xuY29uc3QgaGFzRGVjaW1hbFBsYWNlcyA9IChudW1iZXIpID0+ICEhKG51bWJlciAlIDEpO1xuY29uc3QgZ2VuZXJhdGVTaGVldHMgPSAod29ya2Jvb2ssIGRhdGEsIHRpdGxlU2hlZXQpID0+IHtcbiAgICBjb25zdCBzaGVldCA9IHdvcmtib29rLmFkZFdvcmtzaGVldCh0aXRsZVNoZWV0LCB7XG4gICAgICAgIHZpZXdzOiBbeyBzaG93R3JpZExpbmVzOiB0cnVlIH1dXG4gICAgfSk7XG4gICAgZ2VuZXJhdGVUaXRsZShzaGVldCk7XG4gICAgZ2VuZXJhdGVTdWJUaXRsZShzaGVldCwgZGF0YSk7XG4gICAgZGF0YS5mb3JFYWNoKChkdCwgaW5kZXgpID0+IHtcbiAgICAgICAgY29uc3Qgcm93ID0gc2hlZXQuYWRkUm93KGR0KTtcbiAgICAgICAgcm93LmJvcmRlciA9IGJvcmRlcjtcbiAgICAgICAgcm93LmZvbnQgPSB7XG4gICAgICAgICAgICBuYW1lOiAnVmVyZGFuYScsXG4gICAgICAgICAgICBzaXplOiAxMSxcbiAgICAgICAgICAgIGNvbG9yOiB7IGFyZ2I6IFwiMzMzMzMzXCIgfVxuICAgICAgICB9O1xuICAgICAgICBpZiAoISEoaW5kZXggJSAyKSlcbiAgICAgICAgICAgIHJvdy5maWxsID0ge1xuICAgICAgICAgICAgICAgIHR5cGU6IFwicGF0dGVyblwiLFxuICAgICAgICAgICAgICAgIHBhdHRlcm46IFwic29saWRcIixcbiAgICAgICAgICAgICAgICBmZ0NvbG9yOiB7IGFyZ2I6IFwiRTNFQUVCXCIgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgQXJyYXkuZnJvbSh7IGxlbmd0aDogc2tpcFRleHRDb2x1bW5zIH0sICh4LCBpKSA9PiBhbGlnbkxlZnQocm93LmdldENlbGwoaSArIDEpKSk7XG4gICAgICAgIE9iamVjdC5rZXlzKGR0KS5zbGljZShza2lwVGV4dENvbHVtbnMpLmZvckVhY2goKHByb3AsIGkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNlbGwgPSByb3cuZ2V0Q2VsbChpICsgMSArIHNraXBUZXh0Q29sdW1ucyk7XG4gICAgICAgICAgICBjZWxsLm51bUZtdCA9IGhhc0RlY2ltYWxQbGFjZXMoZHRbcHJvcF0pID8gZGVjaW1hbEZvcm1hdHRpbmcgOiBpbnRGb3JtYXR0aW5nO1xuICAgICAgICB9KTtcbiAgICB9KTtcbn07XG5jb25zdCBnZW5lcmF0ZVRpdGxlID0gKHNoZWV0KSA9PiB7XG4gICAgY29uc3QgdGl0bGVzID0gW1xuICAgICAgICB7IHByb3A6IFwiaWRTdXNlcFwiLCB0aXR1bG86IGBDw7NkaWdvIFNVU0VQYCwgd2lkdGg6IDE3LjI5IH0sXG4gICAgICAgIHsgcHJvcDogXCJlbXByZXNhXCIsIHRpdHVsbzogYEVtcHJlc2FgLCB3aWR0aDogNzIgfSxcbiAgICAgICAgeyBwcm9wOiBcInByZW1pb0VtaXRpZG9cIiwgdGl0dWxvOiBgUHLDqm1pbyBFbWl0aWRvIMKzYCwgd2lkdGg6IDIwLjU3IH0sXG4gICAgICAgIHsgcHJvcDogXCJwcmVtaW9HYW5ob1wiLCB0aXR1bG86IGBQcsOqbWlvIEdhbmhvIMK5YCwgd2lkdGg6IDE5LjI5IH0sXG4gICAgICAgIHsgcHJvcDogXCJkZXNwZXNhUmVzc2VndXJvXCIsIHRpdHVsbzogYERlc3Blc2EgY29tIFJlc3NlZ3VybyDCs2AsIHdpZHRoOiAzMiB9LFxuICAgICAgICB7IHByb3A6IFwic2luaXN0cm9PY29ycmlkb1wiLCB0aXR1bG86IGBTaW5pc3RybyBPY29ycmlkbyDCs2AsIHdpZHRoOiAyMi40MyB9LFxuICAgICAgICB7IHByb3A6IFwicmVjZWl0YVJlc3NlZ3Vyb1wiLCB0aXR1bG86IGBSZWNlaXRhIGNvbSBSZXNzZWd1cm8gwrNgLCB3aWR0aDogMzAuNzEgfSxcbiAgICAgICAgeyBwcm9wOiBcImRlc3Blc2FDb21lcmNpYWxcIiwgdGl0dWxvOiBgRGVzcGVzYSBDb21lcmNpYWxgLCB3aWR0aDogMjMuMTQgfSxcbiAgICAgICAgeyBwcm9wOiBcInNpbmlzdHJhbGlkYWRlXCIsIHRpdHVsbzogYFNpbmlzdHJhbGlkYWRlIMK5YCwgd2lkdGg6IDE4LjU3IH0sXG4gICAgICAgIHsgcHJvcDogXCJydm5lXCIsIHRpdHVsbzogYFJWTkUgwrNgLCB3aWR0aDogMTQuNTcgfSxcbiAgICBdO1xuICAgIHNoZWV0LmNvbHVtbnMgPSB0aXRsZXMubWFwKHRpdGxlID0+ICh7XG4gICAgICAgIGhlYWRlcjogdGl0bGUudGl0dWxvLFxuICAgICAgICBrZXk6IHRpdGxlLnByb3AsXG4gICAgICAgIHdpZHRoOiB0aXRsZS53aWR0aCxcbiAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAgIGZvbnQ6IHtcbiAgICAgICAgICAgICAgICBuYW1lOiAnVmVyZGFuYScsXG4gICAgICAgICAgICAgICAgc2l6ZTogMTEsXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9KSk7XG4gICAgY29uc3Qgcm93VGl0bGUgPSBzaGVldC5nZXRSb3coMSk7XG4gICAgYWxpZ25DZW50ZXIocm93VGl0bGUpO1xuICAgIHNpdHlsaW5nVGl0bGUocm93VGl0bGUpO1xufTtcbmNvbnN0IGdlbmVyYXRlU3ViVGl0bGUgPSAoc2hlZXQsIGRhdGEpID0+IHtcbiAgICBjb25zdCBhbHBoYWJldCA9IFwiQ0RFRkdISUpLTE1OT1BRUlNVVldYWVpcIjtcbiAgICBjb25zdCB0b3RhbHMgPSBbXG4gICAgICAgIHsgdGl0dWxvOiBgYCB9LFxuICAgICAgICB7IHRpdHVsbzogYFRvdGFpc2AgfSxcbiAgICAgICAgLi4uQXJyYXkuZnJvbSh7IGxlbmd0aDogc2hlZXQuY29sdW1ucy5sZW5ndGggLSBza2lwVGV4dENvbHVtbnMgfSwgeiA9PiAoeyB0aXR1bG86IFwiXCIsIHN1bTogdHJ1ZSB9KSlcbiAgICBdO1xuICAgIGNvbnN0IHRvdGFsUm93cyA9IHNoZWV0LmFkZFJvdyhbLi4udG90YWxzXS5tYXAoYSA9PiBhLnRpdHVsbykpO1xuICAgIGFsaWduQ2VudGVyKHRvdGFsUm93cy5nZXRDZWxsKDIpKTtcbiAgICBzaXR5bGluZ1RpdGxlKHRvdGFsUm93cyk7XG4gICAgdG90YWxzLnNsaWNlKHNraXBUZXh0Q29sdW1ucykuZm9yRWFjaCgoeCwgaSkgPT4ge1xuICAgICAgICBjb25zdCBpZENvbCA9IGkgKyAxICsgc2tpcFRleHRDb2x1bW5zO1xuICAgICAgICBjb25zdCBjZWxsID0gdG90YWxSb3dzLmdldENlbGwoaWRDb2wpO1xuICAgICAgICBjb25zdCBwcm9wID0gc2hlZXQuZ2V0Q29sdW1uKGlkQ29sKS5rZXk7XG4gICAgICAgIGNvbnN0IHN1bSA9IGRhdGEucmVkdWNlKChhLCBiKSA9PiBhICsgYltwcm9wXSwgMCk7XG4gICAgICAgIC8qICAgICAgICBjZWxsLnZhbHVlID0ge1xuICAgICAgICAgICAgICAgICAgICBmb3JtdWxhOiBgPVNVTSgke2FscGhhYmV0W2ldfSR7c2tpcFRleHRDb2x1bW5zICsgMX06JHthbHBoYWJldFtpXX0ke2RhdGEubGVuZ3RoICsgMn0pYCxcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0OiBzdW1cbiAgICAgICAgICAgICAgICB9ICovXG4gICAgICAgIGNlbGwubnVtRm10ID0gaGFzRGVjaW1hbFBsYWNlcyhzdW0pID8gZGVjaW1hbEZvcm1hdHRpbmcgOiBpbnRGb3JtYXR0aW5nO1xuICAgIH0pO1xufTtcbmNvbnN0IGRvd25sb2FkRmlsZSA9ICh3b3JrYm9vaywgZmlsZU5hbWUpID0+IHdvcmtib29rLnhsc3gud3JpdGVCdWZmZXIoKVxuICAgIC50aGVuKHJlcyA9PiB7XG4gICAgY29uc3QgZGF0YUZpbGUgPSBuZXcgQmxvYihbcmVzXSwgeyB0eXBlOiBcIm9jdGV0L3N0cmVhbVwiIH0pO1xuICAgIGNvbnN0IHVybCA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKGRhdGFGaWxlKTtcbiAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImFcIik7XG4gICAgYS5zZXRBdHRyaWJ1dGUoXCJzdHlsZVwiLCBcImRpc3BsYXk6IG5vbmVcIik7XG4gICAgYS5ocmVmID0gdXJsO1xuICAgIGEuZG93bmxvYWQgPSBgRGF0YWJhc2UgJHtmaWxlTmFtZX0ueGxzeGA7XG4gICAgYS5jbGljaygpO1xuICAgIHdpbmRvdy5VUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XG59KTtcbiJdLCJzb3VyY2VSb290IjoiIn0=