/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1];
/******/ 		var executeModules = data[2];
/******/
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fulfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fulfilled = false;
/******/ 			}
/******/ 			if(fulfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 	// Promise = chunk loading, 0 = chunk loaded
/******/ 	var installedChunks = {
/******/ 		"contentGenerateSheet": 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push(["./src/contentGenerateSheet.ts","vendor"]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/contentGenerateSheet.ts":
/*!*************************************!*\
  !*** ./src/contentGenerateSheet.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const types_1 = __webpack_require__(/*! ./types */ "./src/types.ts");
const round_1 = __webpack_require__(/*! ./round */ "./src/round.js");
const ExcelJS = __webpack_require__(/*! exceljs/dist/es5/exceljs.browser */ "./node_modules/exceljs/dist/es5/exceljs.browser.js");
const skipLinesTitle = 2;
const textColumns = [1, 2, 6];
const listCentered = [1, 4, 6, 12];
const messager = chrome.runtime.sendMessage;
const decimalFormatting = "#,##0.##";
const intFormatting = "#,##0";
const hasDecimalPlaces = (number) => !!(number % 1);
const border = {
    top: { style: 'thin' },
    left: { style: 'thin' },
    bottom: { style: 'thin' },
    right: { style: 'thin' }
};
const alignLeft = cell => cell.alignment = {
    vertical: 'top',
    horizontal: 'left'
};
const alignCenter = cell => cell.alignment = {
    vertical: 'top',
    horizontal: 'center'
};
const alignRight = cell => cell.alignment = {
    vertical: 'top',
    horizontal: 'right'
};
const sitylingTitle = row => {
    row.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "3f3f3f" }
    };
    row.font = {
        name: 'Verdana',
        size: 9,
        bold: true,
        color: { argb: "ffffff" }
    };
    row.border = border;
};
messager({
    type: types_1.msgType.getDataToExport
}, response => {
    if (!response)
        return;
    const lst = response;
    messager({ type: types_1.msgType.getConfigs }, (configs) => generateSpreadSheet(lst, configs.aggregatedCompanies, configs.nameExportedFile));
});
const generateSpreadSheet = (listaMarket, lstGroups, nameExportedFile) => {
    const workbook = new ExcelJS.Workbook();
    workbook.created = new Date();
    workbook.creator = "Tony Vandré Klava";
    workbook.properties.date1904 = true;
    workbook.views = [
        {
            x: 0, y: 0, width: 10000, height: 20000,
            firstSheet: 0, activeTab: 1, visibility: 'visible'
        }
    ];
    listaMarket.forEach(item => generateSheet(workbook, item, lstGroups));
    downloadFile(workbook, nameExportedFile);
};
const generateSheet = (workbook, mkt, lstGroups) => {
    const sheet = workbook.addWorksheet(mkt.nome, {
        views: [{ showGridLines: true }]
    });
    const labelPeriodoInicial = mkt.periodoFinal.toString().substr(0, 4);
    const labelPeriodoFinal = mkt.periodoFinal.toString().substr(4, 2);
    const firsLabel = `YTD ${labelPeriodoInicial}/${labelPeriodoFinal}  - ${mkt.nome} (${mkt.idRamos.join(', ')})`;
    const columns = [
        { id: "class", name: "Title", subTitle: "Class.", width: 6.14 },
        { id: "empresa", name: firsLabel, subTitle: "Totais", isStyleRed: true, width: 53 },
        { id: "premioEmitidoAtu", name: `Prêmio Emitido (${mkt.periodoFinal.toString().substr(0, 4)})`, width: 23 },
        { id: "mktShare", name: `MKT Share`, subTitle: "100%", width: 10.71 },
        { id: "premioEmitidoAnt", name: `Prêmio Emitido (${mkt.periodoInicial.toString().substr(0, 4)})`, width: 23 },
        { id: "var", name: `Var.`, subTitle: " ", width: 4.43 },
        { id: "premioGanho", name: `Prêmio Ganho`, width: 14 },
        { id: "despesaResseguro", name: `Despesa c/ Resseguro`, width: 22.14 },
        { id: "sinistroOcorrido", name: `Sinistro Ocorrido`, width: 17 },
        { id: "receitaResseguro", name: `Receita c/ Resseguro`, width: 21.14 },
        { id: "despesaComercial", name: `Despesa Comercial`, width: 18.86 },
        { id: "sinistralidade", name: `Sinistralidade`, width: 13.71 },
        { id: "rvne", name: `RVNE`, width: 14.86 },
    ];
    sheet.columns = columns.map(item => ({
        header: item.name,
        key: item.id,
        width: item.width
    }));
    const isEmptyLine = (l) => !l.premioEmitidoAtu;
    const getGroup = (l) => lstGroups.find(group => !!group.idEmpresas.find(c => c === l.idSusep));
    const getAggregatedPremioEmitido = (l) => {
        const group = getGroup(l);
        if (!group)
            return l.premioEmitido;
        return mkt.dadosEmpresaAtual
            .filter(x => !!group.idEmpresas.find(z => z == x.idSusep))
            .reduce((agregado, item) => agregado + item.premioEmitido, 0);
    };
    const dataLines = mkt.dadosEmpresaAtual.map(item => {
        const lastYearData = mkt.dadosEmpresaAnoPassado.find(e => e.idSusep == item.idSusep) || { premioEmitido: 0 };
        return {
            idSusep: item.idSusep,
            empresa: item.empresa,
            premioEmitidoEmpresaAgrupada: getAggregatedPremioEmitido(item),
            premioEmitidoAtu: item.premioEmitido,
            mktShare: "",
            premioEmitidoAnt: lastYearData.premioEmitido,
            var: 0,
            premioGanho: item.premioGanho,
            despesaResseguro: item.despesaResseguro,
            sinistroOcorrido: item.sinistroOcorrido,
            receitaResseguro: item.receitaResseguro,
            despesaComercial: item.despesaComercial,
            sinistralidade: item.sinistralidade,
            rvne: item.rvne
        };
    });
    const lineGroups = lstGroups.map(g => {
        const companies = dataLines.filter(a => !!g.idEmpresas.find(x => x === a.idSusep));
        const sum = (prop) => companies.reduce((a, b) => a + b[prop], 0);
        const agg = (companies[0] && companies[0].premioEmitidoEmpresaAgrupada) || 0;
        return {
            empresa: g.nome,
            premioEmitidoAnt: sum("premioEmitidoAnt"),
            premioEmitidoAtu: sum("premioEmitidoAtu"),
            premioGanho: sum("premioGanho"),
            despesaResseguro: sum("despesaResseguro"),
            sinistroOcorrido: sum("sinistroOcorrido"),
            receitaResseguro: sum("receitaResseguro"),
            despesaComercial: sum("despesaComercial"),
            sinistralidade: sum("sinistralidade"),
            rvne: sum("rvne"),
            premioEmitidoEmpresaAgrupada: agg,
            isGroup: true,
            isAxa: g.isAxa
        };
    });
    const calcTotal = prop => dataLines.reduce((a, b) => a + b[prop], 0);
    const rowSubTitle = sheet.addRow(columns.map(item => item.subTitle || calcTotal(item.id)));
    sheet.columns.forEach((col, o) => {
        const cell = rowSubTitle.getCell(o + 1);
        cell.numFmt = hasDecimalPlaces(cell.value) ? decimalFormatting : intFormatting;
    });
    const allLines = [...dataLines, ...lineGroups];
    const totalPremioEmitido = calcTotal(columns[2].id);
    const totalPremioEmitidoAnoPassado = calcTotal(columns[4].id);
    //align Totais
    [...listCentered, 2].forEach(x => alignCenter(rowSubTitle.getCell(x)));
    //set column var
    rowSubTitle.getCell(6).value =
        totalPremioEmitido > totalPremioEmitidoAnoPassado ? 1 : 0;
    //set column sinestridade
    rowSubTitle.getCell(12).value = mkt.totalSinistridade;
    let countClassification = 1;
    allLines
        .filter(line => !isEmptyLine(line))
        .sort((a, b) => {
        if (a.premioEmitidoEmpresaAgrupada > b.premioEmitidoEmpresaAgrupada)
            return -1;
        if (a.premioEmitidoEmpresaAgrupada < b.premioEmitidoEmpresaAgrupada)
            return 1;
        if (a.isGroup)
            return -1;
        return 0;
    })
        .forEach((line, index) => {
        const row = sheet.addRow(line);
        const group = getGroup(line);
        if (!!group)
            row.outlineLevel = 1;
        else
            row.getCell(1).value = `${countClassification++}º`;
        //set mktShare
        const mktShare = row.getCell(4);
        mktShare.value = `${(round_1.roundNumber(line.premioEmitidoAtu * 1000 / totalPremioEmitido, 1) / 10).toFixed(2)}%`;
        mktShare.numFmt = "00.0%";
        const mktVar = row.getCell(6);
        mktVar.value = line.premioEmitidoAtu > line.premioEmitidoAnt ? 1 : 0;
        Object.keys(line).forEach((prop, i) => {
            const idCol = i + 1;
            const cell = row.getCell(idCol);
            if (!textColumns.find(v => v == idCol)) {
                cell.numFmt = hasDecimalPlaces(line[prop]) ? decimalFormatting : intFormatting;
                alignRight(cell);
            }
            if (idCol === 2)
                alignLeft(cell);
            if (listCentered.find(c => c === idCol))
                alignCenter(cell);
            cell.border = border;
            cell.font = {
                name: 'Verdana',
                size: 9,
                color: { argb: "333333" }
            };
            if (line.isAxa) {
                cell.font = {
                    name: 'Verdana',
                    size: 9,
                    bold: true,
                    color: { argb: "333333" }
                };
                cell.fill = {
                    type: "pattern",
                    pattern: "solid",
                    fgColor: { argb: "FFFF00" }
                };
            }
        });
    });
    Array.from({ length: skipLinesTitle }, (a, i) => sheet.columns.forEach((col, z) => sitylingTitle(sheet.getRow(i + 1).getCell(z + 1))));
    sheet.getRow(1).getCell(1).value = "";
    sheet.mergeCells("A1:B1");
    sheet.getRow(1).getCell(1).fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "C00000" }
    };
    const cell = sheet.getCell("A1");
    cell.value = columns[1].name;
    alignCenter(cell);
    sheet.properties.outlineLevelRow = 1;
    messager({ type: types_1.msgType.finishiesExportSpreadSheet });
};
const downloadFile = (workbook, fileName) => workbook.xlsx.writeBuffer()
    .then(res => {
    const dataFile = new Blob([res], { type: "octet/stream" });
    const url = window.URL.createObjectURL(dataFile);
    const a = document.createElement("a");
    a.setAttribute("style", "display: none");
    a.href = url;
    a.download = `${fileName}.xlsx`;
    a.click();
    window.URL.revokeObjectURL(url);
});


/***/ }),

/***/ "./src/round.js":
/*!**********************!*\
  !*** ./src/round.js ***!
  \**********************/
/*! exports provided: roundNumber */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "roundNumber", function() { return roundNumber; });

const roundNumber = (num, scale) => {
    if(!("" + num).includes("e")) {
        return +(Math.round(num + "e+" + scale)  + "e-" + scale);
    } else {
        var arr = ("" + num).split("e");
        var sig = ""
        if(+arr[1] + scale > 0) {
            sig = "+";
        }
        return +(Math.round(+arr[0] + "e" + sig + (+arr[1] + scale)) + "e-" + scale);
    }
}

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbnRlbnRHZW5lcmF0ZVNoZWV0LnRzIiwid2VicGFjazovLy8uL3NyYy9yb3VuZC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxnQkFBUSxvQkFBb0I7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBaUIsNEJBQTRCO0FBQzdDO0FBQ0E7QUFDQSwwQkFBa0IsMkJBQTJCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGtEQUEwQyxnQ0FBZ0M7QUFDMUU7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxnRUFBd0Qsa0JBQWtCO0FBQzFFO0FBQ0EseURBQWlELGNBQWM7QUFDL0Q7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUF5QyxpQ0FBaUM7QUFDMUUsd0hBQWdILG1CQUFtQixFQUFFO0FBQ3JJO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsbUNBQTJCLDBCQUEwQixFQUFFO0FBQ3ZELHlDQUFpQyxlQUFlO0FBQ2hEO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDhEQUFzRCwrREFBK0Q7O0FBRXJIO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBZ0IsdUJBQXVCO0FBQ3ZDOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3RKYTtBQUNiLDhDQUE4QyxjQUFjO0FBQzVELGdCQUFnQixtQkFBTyxDQUFDLCtCQUFTO0FBQ2pDLGdCQUFnQixtQkFBTyxDQUFDLCtCQUFTO0FBQ2pDLGdCQUFnQixtQkFBTyxDQUFDLDRGQUFrQztBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVSxnQkFBZ0I7QUFDMUIsV0FBVyxnQkFBZ0I7QUFDM0IsYUFBYSxnQkFBZ0I7QUFDN0IsWUFBWTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLGNBQWMsbUNBQW1DO0FBQ2pELENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixzQkFBc0I7QUFDdkMsS0FBSztBQUNMO0FBQ0E7QUFDQSw2QkFBNkIsb0JBQW9CLEdBQUcsa0JBQWtCLE1BQU0sU0FBUyxJQUFJLHVCQUF1QjtBQUNoSDtBQUNBLFNBQVMsOERBQThEO0FBQ3ZFLFNBQVMsa0ZBQWtGO0FBQzNGLFNBQVMsa0RBQWtELHlDQUF5QyxlQUFlO0FBQ25ILFNBQVMsb0VBQW9FO0FBQzdFLFNBQVMsa0RBQWtELDJDQUEyQyxlQUFlO0FBQ3JILFNBQVMsc0RBQXNEO0FBQy9ELFNBQVMscURBQXFEO0FBQzlELFNBQVMscUVBQXFFO0FBQzlFLFNBQVMsK0RBQStEO0FBQ3hFLFNBQVMscUVBQXFFO0FBQzlFLFNBQVMsa0VBQWtFO0FBQzNFLFNBQVMsNkRBQTZEO0FBQ3RFLFNBQVMseUNBQXlDO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlHQUFpRztBQUNqRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0Msc0JBQXNCO0FBQzVEO0FBQ0E7QUFDQSw0QkFBNEIsNEZBQTRGO0FBQ3hIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEI7QUFDOUI7QUFDQTtBQUNBLFNBQVM7QUFDVCxLQUFLO0FBQ0wsZ0JBQWdCLHlCQUF5QjtBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFjLG1EQUFtRDtBQUNqRTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0MsdUJBQXVCO0FBQzdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0JBQW9CLFNBQVM7QUFDN0I7QUFDQTtBQUNBLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5T007QUFDUDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQyIsImZpbGUiOiJjb250ZW50R2VuZXJhdGVTaGVldC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIGluc3RhbGwgYSBKU09OUCBjYWxsYmFjayBmb3IgY2h1bmsgbG9hZGluZ1xuIFx0ZnVuY3Rpb24gd2VicGFja0pzb25wQ2FsbGJhY2soZGF0YSkge1xuIFx0XHR2YXIgY2h1bmtJZHMgPSBkYXRhWzBdO1xuIFx0XHR2YXIgbW9yZU1vZHVsZXMgPSBkYXRhWzFdO1xuIFx0XHR2YXIgZXhlY3V0ZU1vZHVsZXMgPSBkYXRhWzJdO1xuXG4gXHRcdC8vIGFkZCBcIm1vcmVNb2R1bGVzXCIgdG8gdGhlIG1vZHVsZXMgb2JqZWN0LFxuIFx0XHQvLyB0aGVuIGZsYWcgYWxsIFwiY2h1bmtJZHNcIiBhcyBsb2FkZWQgYW5kIGZpcmUgY2FsbGJhY2tcbiBcdFx0dmFyIG1vZHVsZUlkLCBjaHVua0lkLCBpID0gMCwgcmVzb2x2ZXMgPSBbXTtcbiBcdFx0Zm9yKDtpIDwgY2h1bmtJZHMubGVuZ3RoOyBpKyspIHtcbiBcdFx0XHRjaHVua0lkID0gY2h1bmtJZHNbaV07XG4gXHRcdFx0aWYoaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdKSB7XG4gXHRcdFx0XHRyZXNvbHZlcy5wdXNoKGluc3RhbGxlZENodW5rc1tjaHVua0lkXVswXSk7XG4gXHRcdFx0fVxuIFx0XHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkXSA9IDA7XG4gXHRcdH1cbiBcdFx0Zm9yKG1vZHVsZUlkIGluIG1vcmVNb2R1bGVzKSB7XG4gXHRcdFx0aWYoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG1vcmVNb2R1bGVzLCBtb2R1bGVJZCkpIHtcbiBcdFx0XHRcdG1vZHVsZXNbbW9kdWxlSWRdID0gbW9yZU1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHRcdH1cbiBcdFx0fVxuIFx0XHRpZihwYXJlbnRKc29ucEZ1bmN0aW9uKSBwYXJlbnRKc29ucEZ1bmN0aW9uKGRhdGEpO1xuXG4gXHRcdHdoaWxlKHJlc29sdmVzLmxlbmd0aCkge1xuIFx0XHRcdHJlc29sdmVzLnNoaWZ0KCkoKTtcbiBcdFx0fVxuXG4gXHRcdC8vIGFkZCBlbnRyeSBtb2R1bGVzIGZyb20gbG9hZGVkIGNodW5rIHRvIGRlZmVycmVkIGxpc3RcbiBcdFx0ZGVmZXJyZWRNb2R1bGVzLnB1c2guYXBwbHkoZGVmZXJyZWRNb2R1bGVzLCBleGVjdXRlTW9kdWxlcyB8fCBbXSk7XG5cbiBcdFx0Ly8gcnVuIGRlZmVycmVkIG1vZHVsZXMgd2hlbiBhbGwgY2h1bmtzIHJlYWR5XG4gXHRcdHJldHVybiBjaGVja0RlZmVycmVkTW9kdWxlcygpO1xuIFx0fTtcbiBcdGZ1bmN0aW9uIGNoZWNrRGVmZXJyZWRNb2R1bGVzKCkge1xuIFx0XHR2YXIgcmVzdWx0O1xuIFx0XHRmb3IodmFyIGkgPSAwOyBpIDwgZGVmZXJyZWRNb2R1bGVzLmxlbmd0aDsgaSsrKSB7XG4gXHRcdFx0dmFyIGRlZmVycmVkTW9kdWxlID0gZGVmZXJyZWRNb2R1bGVzW2ldO1xuIFx0XHRcdHZhciBmdWxmaWxsZWQgPSB0cnVlO1xuIFx0XHRcdGZvcih2YXIgaiA9IDE7IGogPCBkZWZlcnJlZE1vZHVsZS5sZW5ndGg7IGorKykge1xuIFx0XHRcdFx0dmFyIGRlcElkID0gZGVmZXJyZWRNb2R1bGVbal07XG4gXHRcdFx0XHRpZihpbnN0YWxsZWRDaHVua3NbZGVwSWRdICE9PSAwKSBmdWxmaWxsZWQgPSBmYWxzZTtcbiBcdFx0XHR9XG4gXHRcdFx0aWYoZnVsZmlsbGVkKSB7XG4gXHRcdFx0XHRkZWZlcnJlZE1vZHVsZXMuc3BsaWNlKGktLSwgMSk7XG4gXHRcdFx0XHRyZXN1bHQgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IGRlZmVycmVkTW9kdWxlWzBdKTtcbiBcdFx0XHR9XG4gXHRcdH1cbiBcdFx0cmV0dXJuIHJlc3VsdDtcbiBcdH1cblxuIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gb2JqZWN0IHRvIHN0b3JlIGxvYWRlZCBhbmQgbG9hZGluZyBjaHVua3NcbiBcdC8vIHVuZGVmaW5lZCA9IGNodW5rIG5vdCBsb2FkZWQsIG51bGwgPSBjaHVuayBwcmVsb2FkZWQvcHJlZmV0Y2hlZFxuIFx0Ly8gUHJvbWlzZSA9IGNodW5rIGxvYWRpbmcsIDAgPSBjaHVuayBsb2FkZWRcbiBcdHZhciBpbnN0YWxsZWRDaHVua3MgPSB7XG4gXHRcdFwiY29udGVudEdlbmVyYXRlU2hlZXRcIjogMFxuIFx0fTtcblxuIFx0dmFyIGRlZmVycmVkTW9kdWxlcyA9IFtdO1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG4gXHR2YXIganNvbnBBcnJheSA9IHdpbmRvd1tcIndlYnBhY2tKc29ucFwiXSA9IHdpbmRvd1tcIndlYnBhY2tKc29ucFwiXSB8fCBbXTtcbiBcdHZhciBvbGRKc29ucEZ1bmN0aW9uID0ganNvbnBBcnJheS5wdXNoLmJpbmQoanNvbnBBcnJheSk7XG4gXHRqc29ucEFycmF5LnB1c2ggPSB3ZWJwYWNrSnNvbnBDYWxsYmFjaztcbiBcdGpzb25wQXJyYXkgPSBqc29ucEFycmF5LnNsaWNlKCk7XG4gXHRmb3IodmFyIGkgPSAwOyBpIDwganNvbnBBcnJheS5sZW5ndGg7IGkrKykgd2VicGFja0pzb25wQ2FsbGJhY2soanNvbnBBcnJheVtpXSk7XG4gXHR2YXIgcGFyZW50SnNvbnBGdW5jdGlvbiA9IG9sZEpzb25wRnVuY3Rpb247XG5cblxuIFx0Ly8gYWRkIGVudHJ5IG1vZHVsZSB0byBkZWZlcnJlZCBsaXN0XG4gXHRkZWZlcnJlZE1vZHVsZXMucHVzaChbXCIuL3NyYy9jb250ZW50R2VuZXJhdGVTaGVldC50c1wiLFwidmVuZG9yXCJdKTtcbiBcdC8vIHJ1biBkZWZlcnJlZCBtb2R1bGVzIHdoZW4gcmVhZHlcbiBcdHJldHVybiBjaGVja0RlZmVycmVkTW9kdWxlcygpO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5jb25zdCB0eXBlc18xID0gcmVxdWlyZShcIi4vdHlwZXNcIik7XG5jb25zdCByb3VuZF8xID0gcmVxdWlyZShcIi4vcm91bmRcIik7XG5jb25zdCBFeGNlbEpTID0gcmVxdWlyZShcImV4Y2VsanMvZGlzdC9lczUvZXhjZWxqcy5icm93c2VyXCIpO1xuY29uc3Qgc2tpcExpbmVzVGl0bGUgPSAyO1xuY29uc3QgdGV4dENvbHVtbnMgPSBbMSwgMiwgNl07XG5jb25zdCBsaXN0Q2VudGVyZWQgPSBbMSwgNCwgNiwgMTJdO1xuY29uc3QgbWVzc2FnZXIgPSBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZTtcbmNvbnN0IGRlY2ltYWxGb3JtYXR0aW5nID0gXCIjLCMjMC4jI1wiO1xuY29uc3QgaW50Rm9ybWF0dGluZyA9IFwiIywjIzBcIjtcbmNvbnN0IGhhc0RlY2ltYWxQbGFjZXMgPSAobnVtYmVyKSA9PiAhIShudW1iZXIgJSAxKTtcbmNvbnN0IGJvcmRlciA9IHtcbiAgICB0b3A6IHsgc3R5bGU6ICd0aGluJyB9LFxuICAgIGxlZnQ6IHsgc3R5bGU6ICd0aGluJyB9LFxuICAgIGJvdHRvbTogeyBzdHlsZTogJ3RoaW4nIH0sXG4gICAgcmlnaHQ6IHsgc3R5bGU6ICd0aGluJyB9XG59O1xuY29uc3QgYWxpZ25MZWZ0ID0gY2VsbCA9PiBjZWxsLmFsaWdubWVudCA9IHtcbiAgICB2ZXJ0aWNhbDogJ3RvcCcsXG4gICAgaG9yaXpvbnRhbDogJ2xlZnQnXG59O1xuY29uc3QgYWxpZ25DZW50ZXIgPSBjZWxsID0+IGNlbGwuYWxpZ25tZW50ID0ge1xuICAgIHZlcnRpY2FsOiAndG9wJyxcbiAgICBob3Jpem9udGFsOiAnY2VudGVyJ1xufTtcbmNvbnN0IGFsaWduUmlnaHQgPSBjZWxsID0+IGNlbGwuYWxpZ25tZW50ID0ge1xuICAgIHZlcnRpY2FsOiAndG9wJyxcbiAgICBob3Jpem9udGFsOiAncmlnaHQnXG59O1xuY29uc3Qgc2l0eWxpbmdUaXRsZSA9IHJvdyA9PiB7XG4gICAgcm93LmZpbGwgPSB7XG4gICAgICAgIHR5cGU6IFwicGF0dGVyblwiLFxuICAgICAgICBwYXR0ZXJuOiBcInNvbGlkXCIsXG4gICAgICAgIGZnQ29sb3I6IHsgYXJnYjogXCIzZjNmM2ZcIiB9XG4gICAgfTtcbiAgICByb3cuZm9udCA9IHtcbiAgICAgICAgbmFtZTogJ1ZlcmRhbmEnLFxuICAgICAgICBzaXplOiA5LFxuICAgICAgICBib2xkOiB0cnVlLFxuICAgICAgICBjb2xvcjogeyBhcmdiOiBcImZmZmZmZlwiIH1cbiAgICB9O1xuICAgIHJvdy5ib3JkZXIgPSBib3JkZXI7XG59O1xubWVzc2FnZXIoe1xuICAgIHR5cGU6IHR5cGVzXzEubXNnVHlwZS5nZXREYXRhVG9FeHBvcnRcbn0sIHJlc3BvbnNlID0+IHtcbiAgICBpZiAoIXJlc3BvbnNlKVxuICAgICAgICByZXR1cm47XG4gICAgY29uc3QgbHN0ID0gcmVzcG9uc2U7XG4gICAgbWVzc2FnZXIoeyB0eXBlOiB0eXBlc18xLm1zZ1R5cGUuZ2V0Q29uZmlncyB9LCAoY29uZmlncykgPT4gZ2VuZXJhdGVTcHJlYWRTaGVldChsc3QsIGNvbmZpZ3MuYWdncmVnYXRlZENvbXBhbmllcywgY29uZmlncy5uYW1lRXhwb3J0ZWRGaWxlKSk7XG59KTtcbmNvbnN0IGdlbmVyYXRlU3ByZWFkU2hlZXQgPSAobGlzdGFNYXJrZXQsIGxzdEdyb3VwcywgbmFtZUV4cG9ydGVkRmlsZSkgPT4ge1xuICAgIGNvbnN0IHdvcmtib29rID0gbmV3IEV4Y2VsSlMuV29ya2Jvb2soKTtcbiAgICB3b3JrYm9vay5jcmVhdGVkID0gbmV3IERhdGUoKTtcbiAgICB3b3JrYm9vay5jcmVhdG9yID0gXCJUb255IFZhbmRyw6kgS2xhdmFcIjtcbiAgICB3b3JrYm9vay5wcm9wZXJ0aWVzLmRhdGUxOTA0ID0gdHJ1ZTtcbiAgICB3b3JrYm9vay52aWV3cyA9IFtcbiAgICAgICAge1xuICAgICAgICAgICAgeDogMCwgeTogMCwgd2lkdGg6IDEwMDAwLCBoZWlnaHQ6IDIwMDAwLFxuICAgICAgICAgICAgZmlyc3RTaGVldDogMCwgYWN0aXZlVGFiOiAxLCB2aXNpYmlsaXR5OiAndmlzaWJsZSdcbiAgICAgICAgfVxuICAgIF07XG4gICAgbGlzdGFNYXJrZXQuZm9yRWFjaChpdGVtID0+IGdlbmVyYXRlU2hlZXQod29ya2Jvb2ssIGl0ZW0sIGxzdEdyb3VwcykpO1xuICAgIGRvd25sb2FkRmlsZSh3b3JrYm9vaywgbmFtZUV4cG9ydGVkRmlsZSk7XG59O1xuY29uc3QgZ2VuZXJhdGVTaGVldCA9ICh3b3JrYm9vaywgbWt0LCBsc3RHcm91cHMpID0+IHtcbiAgICBjb25zdCBzaGVldCA9IHdvcmtib29rLmFkZFdvcmtzaGVldChta3Qubm9tZSwge1xuICAgICAgICB2aWV3czogW3sgc2hvd0dyaWRMaW5lczogdHJ1ZSB9XVxuICAgIH0pO1xuICAgIGNvbnN0IGxhYmVsUGVyaW9kb0luaWNpYWwgPSBta3QucGVyaW9kb0ZpbmFsLnRvU3RyaW5nKCkuc3Vic3RyKDAsIDQpO1xuICAgIGNvbnN0IGxhYmVsUGVyaW9kb0ZpbmFsID0gbWt0LnBlcmlvZG9GaW5hbC50b1N0cmluZygpLnN1YnN0cig0LCAyKTtcbiAgICBjb25zdCBmaXJzTGFiZWwgPSBgWVREICR7bGFiZWxQZXJpb2RvSW5pY2lhbH0vJHtsYWJlbFBlcmlvZG9GaW5hbH0gIC0gJHtta3Qubm9tZX0gKCR7bWt0LmlkUmFtb3Muam9pbignLCAnKX0pYDtcbiAgICBjb25zdCBjb2x1bW5zID0gW1xuICAgICAgICB7IGlkOiBcImNsYXNzXCIsIG5hbWU6IFwiVGl0bGVcIiwgc3ViVGl0bGU6IFwiQ2xhc3MuXCIsIHdpZHRoOiA2LjE0IH0sXG4gICAgICAgIHsgaWQ6IFwiZW1wcmVzYVwiLCBuYW1lOiBmaXJzTGFiZWwsIHN1YlRpdGxlOiBcIlRvdGFpc1wiLCBpc1N0eWxlUmVkOiB0cnVlLCB3aWR0aDogNTMgfSxcbiAgICAgICAgeyBpZDogXCJwcmVtaW9FbWl0aWRvQXR1XCIsIG5hbWU6IGBQcsOqbWlvIEVtaXRpZG8gKCR7bWt0LnBlcmlvZG9GaW5hbC50b1N0cmluZygpLnN1YnN0cigwLCA0KX0pYCwgd2lkdGg6IDIzIH0sXG4gICAgICAgIHsgaWQ6IFwibWt0U2hhcmVcIiwgbmFtZTogYE1LVCBTaGFyZWAsIHN1YlRpdGxlOiBcIjEwMCVcIiwgd2lkdGg6IDEwLjcxIH0sXG4gICAgICAgIHsgaWQ6IFwicHJlbWlvRW1pdGlkb0FudFwiLCBuYW1lOiBgUHLDqm1pbyBFbWl0aWRvICgke21rdC5wZXJpb2RvSW5pY2lhbC50b1N0cmluZygpLnN1YnN0cigwLCA0KX0pYCwgd2lkdGg6IDIzIH0sXG4gICAgICAgIHsgaWQ6IFwidmFyXCIsIG5hbWU6IGBWYXIuYCwgc3ViVGl0bGU6IFwiIFwiLCB3aWR0aDogNC40MyB9LFxuICAgICAgICB7IGlkOiBcInByZW1pb0dhbmhvXCIsIG5hbWU6IGBQcsOqbWlvIEdhbmhvYCwgd2lkdGg6IDE0IH0sXG4gICAgICAgIHsgaWQ6IFwiZGVzcGVzYVJlc3NlZ3Vyb1wiLCBuYW1lOiBgRGVzcGVzYSBjLyBSZXNzZWd1cm9gLCB3aWR0aDogMjIuMTQgfSxcbiAgICAgICAgeyBpZDogXCJzaW5pc3Ryb09jb3JyaWRvXCIsIG5hbWU6IGBTaW5pc3RybyBPY29ycmlkb2AsIHdpZHRoOiAxNyB9LFxuICAgICAgICB7IGlkOiBcInJlY2VpdGFSZXNzZWd1cm9cIiwgbmFtZTogYFJlY2VpdGEgYy8gUmVzc2VndXJvYCwgd2lkdGg6IDIxLjE0IH0sXG4gICAgICAgIHsgaWQ6IFwiZGVzcGVzYUNvbWVyY2lhbFwiLCBuYW1lOiBgRGVzcGVzYSBDb21lcmNpYWxgLCB3aWR0aDogMTguODYgfSxcbiAgICAgICAgeyBpZDogXCJzaW5pc3RyYWxpZGFkZVwiLCBuYW1lOiBgU2luaXN0cmFsaWRhZGVgLCB3aWR0aDogMTMuNzEgfSxcbiAgICAgICAgeyBpZDogXCJydm5lXCIsIG5hbWU6IGBSVk5FYCwgd2lkdGg6IDE0Ljg2IH0sXG4gICAgXTtcbiAgICBzaGVldC5jb2x1bW5zID0gY29sdW1ucy5tYXAoaXRlbSA9PiAoe1xuICAgICAgICBoZWFkZXI6IGl0ZW0ubmFtZSxcbiAgICAgICAga2V5OiBpdGVtLmlkLFxuICAgICAgICB3aWR0aDogaXRlbS53aWR0aFxuICAgIH0pKTtcbiAgICBjb25zdCBpc0VtcHR5TGluZSA9IChsKSA9PiAhbC5wcmVtaW9FbWl0aWRvQXR1O1xuICAgIGNvbnN0IGdldEdyb3VwID0gKGwpID0+IGxzdEdyb3Vwcy5maW5kKGdyb3VwID0+ICEhZ3JvdXAuaWRFbXByZXNhcy5maW5kKGMgPT4gYyA9PT0gbC5pZFN1c2VwKSk7XG4gICAgY29uc3QgZ2V0QWdncmVnYXRlZFByZW1pb0VtaXRpZG8gPSAobCkgPT4ge1xuICAgICAgICBjb25zdCBncm91cCA9IGdldEdyb3VwKGwpO1xuICAgICAgICBpZiAoIWdyb3VwKVxuICAgICAgICAgICAgcmV0dXJuIGwucHJlbWlvRW1pdGlkbztcbiAgICAgICAgcmV0dXJuIG1rdC5kYWRvc0VtcHJlc2FBdHVhbFxuICAgICAgICAgICAgLmZpbHRlcih4ID0+ICEhZ3JvdXAuaWRFbXByZXNhcy5maW5kKHogPT4geiA9PSB4LmlkU3VzZXApKVxuICAgICAgICAgICAgLnJlZHVjZSgoYWdyZWdhZG8sIGl0ZW0pID0+IGFncmVnYWRvICsgaXRlbS5wcmVtaW9FbWl0aWRvLCAwKTtcbiAgICB9O1xuICAgIGNvbnN0IGRhdGFMaW5lcyA9IG1rdC5kYWRvc0VtcHJlc2FBdHVhbC5tYXAoaXRlbSA9PiB7XG4gICAgICAgIGNvbnN0IGxhc3RZZWFyRGF0YSA9IG1rdC5kYWRvc0VtcHJlc2FBbm9QYXNzYWRvLmZpbmQoZSA9PiBlLmlkU3VzZXAgPT0gaXRlbS5pZFN1c2VwKSB8fCB7IHByZW1pb0VtaXRpZG86IDAgfTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGlkU3VzZXA6IGl0ZW0uaWRTdXNlcCxcbiAgICAgICAgICAgIGVtcHJlc2E6IGl0ZW0uZW1wcmVzYSxcbiAgICAgICAgICAgIHByZW1pb0VtaXRpZG9FbXByZXNhQWdydXBhZGE6IGdldEFnZ3JlZ2F0ZWRQcmVtaW9FbWl0aWRvKGl0ZW0pLFxuICAgICAgICAgICAgcHJlbWlvRW1pdGlkb0F0dTogaXRlbS5wcmVtaW9FbWl0aWRvLFxuICAgICAgICAgICAgbWt0U2hhcmU6IFwiXCIsXG4gICAgICAgICAgICBwcmVtaW9FbWl0aWRvQW50OiBsYXN0WWVhckRhdGEucHJlbWlvRW1pdGlkbyxcbiAgICAgICAgICAgIHZhcjogMCxcbiAgICAgICAgICAgIHByZW1pb0dhbmhvOiBpdGVtLnByZW1pb0dhbmhvLFxuICAgICAgICAgICAgZGVzcGVzYVJlc3NlZ3VybzogaXRlbS5kZXNwZXNhUmVzc2VndXJvLFxuICAgICAgICAgICAgc2luaXN0cm9PY29ycmlkbzogaXRlbS5zaW5pc3Ryb09jb3JyaWRvLFxuICAgICAgICAgICAgcmVjZWl0YVJlc3NlZ3VybzogaXRlbS5yZWNlaXRhUmVzc2VndXJvLFxuICAgICAgICAgICAgZGVzcGVzYUNvbWVyY2lhbDogaXRlbS5kZXNwZXNhQ29tZXJjaWFsLFxuICAgICAgICAgICAgc2luaXN0cmFsaWRhZGU6IGl0ZW0uc2luaXN0cmFsaWRhZGUsXG4gICAgICAgICAgICBydm5lOiBpdGVtLnJ2bmVcbiAgICAgICAgfTtcbiAgICB9KTtcbiAgICBjb25zdCBsaW5lR3JvdXBzID0gbHN0R3JvdXBzLm1hcChnID0+IHtcbiAgICAgICAgY29uc3QgY29tcGFuaWVzID0gZGF0YUxpbmVzLmZpbHRlcihhID0+ICEhZy5pZEVtcHJlc2FzLmZpbmQoeCA9PiB4ID09PSBhLmlkU3VzZXApKTtcbiAgICAgICAgY29uc3Qgc3VtID0gKHByb3ApID0+IGNvbXBhbmllcy5yZWR1Y2UoKGEsIGIpID0+IGEgKyBiW3Byb3BdLCAwKTtcbiAgICAgICAgY29uc3QgYWdnID0gKGNvbXBhbmllc1swXSAmJiBjb21wYW5pZXNbMF0ucHJlbWlvRW1pdGlkb0VtcHJlc2FBZ3J1cGFkYSkgfHwgMDtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGVtcHJlc2E6IGcubm9tZSxcbiAgICAgICAgICAgIHByZW1pb0VtaXRpZG9BbnQ6IHN1bShcInByZW1pb0VtaXRpZG9BbnRcIiksXG4gICAgICAgICAgICBwcmVtaW9FbWl0aWRvQXR1OiBzdW0oXCJwcmVtaW9FbWl0aWRvQXR1XCIpLFxuICAgICAgICAgICAgcHJlbWlvR2FuaG86IHN1bShcInByZW1pb0dhbmhvXCIpLFxuICAgICAgICAgICAgZGVzcGVzYVJlc3NlZ3Vybzogc3VtKFwiZGVzcGVzYVJlc3NlZ3Vyb1wiKSxcbiAgICAgICAgICAgIHNpbmlzdHJvT2NvcnJpZG86IHN1bShcInNpbmlzdHJvT2NvcnJpZG9cIiksXG4gICAgICAgICAgICByZWNlaXRhUmVzc2VndXJvOiBzdW0oXCJyZWNlaXRhUmVzc2VndXJvXCIpLFxuICAgICAgICAgICAgZGVzcGVzYUNvbWVyY2lhbDogc3VtKFwiZGVzcGVzYUNvbWVyY2lhbFwiKSxcbiAgICAgICAgICAgIHNpbmlzdHJhbGlkYWRlOiBzdW0oXCJzaW5pc3RyYWxpZGFkZVwiKSxcbiAgICAgICAgICAgIHJ2bmU6IHN1bShcInJ2bmVcIiksXG4gICAgICAgICAgICBwcmVtaW9FbWl0aWRvRW1wcmVzYUFncnVwYWRhOiBhZ2csXG4gICAgICAgICAgICBpc0dyb3VwOiB0cnVlLFxuICAgICAgICAgICAgaXNBeGE6IGcuaXNBeGFcbiAgICAgICAgfTtcbiAgICB9KTtcbiAgICBjb25zdCBjYWxjVG90YWwgPSBwcm9wID0+IGRhdGFMaW5lcy5yZWR1Y2UoKGEsIGIpID0+IGEgKyBiW3Byb3BdLCAwKTtcbiAgICBjb25zdCByb3dTdWJUaXRsZSA9IHNoZWV0LmFkZFJvdyhjb2x1bW5zLm1hcChpdGVtID0+IGl0ZW0uc3ViVGl0bGUgfHwgY2FsY1RvdGFsKGl0ZW0uaWQpKSk7XG4gICAgc2hlZXQuY29sdW1ucy5mb3JFYWNoKChjb2wsIG8pID0+IHtcbiAgICAgICAgY29uc3QgY2VsbCA9IHJvd1N1YlRpdGxlLmdldENlbGwobyArIDEpO1xuICAgICAgICBjZWxsLm51bUZtdCA9IGhhc0RlY2ltYWxQbGFjZXMoY2VsbC52YWx1ZSkgPyBkZWNpbWFsRm9ybWF0dGluZyA6IGludEZvcm1hdHRpbmc7XG4gICAgfSk7XG4gICAgY29uc3QgYWxsTGluZXMgPSBbLi4uZGF0YUxpbmVzLCAuLi5saW5lR3JvdXBzXTtcbiAgICBjb25zdCB0b3RhbFByZW1pb0VtaXRpZG8gPSBjYWxjVG90YWwoY29sdW1uc1syXS5pZCk7XG4gICAgY29uc3QgdG90YWxQcmVtaW9FbWl0aWRvQW5vUGFzc2FkbyA9IGNhbGNUb3RhbChjb2x1bW5zWzRdLmlkKTtcbiAgICAvL2FsaWduIFRvdGFpc1xuICAgIFsuLi5saXN0Q2VudGVyZWQsIDJdLmZvckVhY2goeCA9PiBhbGlnbkNlbnRlcihyb3dTdWJUaXRsZS5nZXRDZWxsKHgpKSk7XG4gICAgLy9zZXQgY29sdW1uIHZhclxuICAgIHJvd1N1YlRpdGxlLmdldENlbGwoNikudmFsdWUgPVxuICAgICAgICB0b3RhbFByZW1pb0VtaXRpZG8gPiB0b3RhbFByZW1pb0VtaXRpZG9Bbm9QYXNzYWRvID8gMSA6IDA7XG4gICAgLy9zZXQgY29sdW1uIHNpbmVzdHJpZGFkZVxuICAgIHJvd1N1YlRpdGxlLmdldENlbGwoMTIpLnZhbHVlID0gbWt0LnRvdGFsU2luaXN0cmlkYWRlO1xuICAgIGxldCBjb3VudENsYXNzaWZpY2F0aW9uID0gMTtcbiAgICBhbGxMaW5lc1xuICAgICAgICAuZmlsdGVyKGxpbmUgPT4gIWlzRW1wdHlMaW5lKGxpbmUpKVxuICAgICAgICAuc29ydCgoYSwgYikgPT4ge1xuICAgICAgICBpZiAoYS5wcmVtaW9FbWl0aWRvRW1wcmVzYUFncnVwYWRhID4gYi5wcmVtaW9FbWl0aWRvRW1wcmVzYUFncnVwYWRhKVxuICAgICAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgICBpZiAoYS5wcmVtaW9FbWl0aWRvRW1wcmVzYUFncnVwYWRhIDwgYi5wcmVtaW9FbWl0aWRvRW1wcmVzYUFncnVwYWRhKVxuICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICAgIGlmIChhLmlzR3JvdXApXG4gICAgICAgICAgICByZXR1cm4gLTE7XG4gICAgICAgIHJldHVybiAwO1xuICAgIH0pXG4gICAgICAgIC5mb3JFYWNoKChsaW5lLCBpbmRleCkgPT4ge1xuICAgICAgICBjb25zdCByb3cgPSBzaGVldC5hZGRSb3cobGluZSk7XG4gICAgICAgIGNvbnN0IGdyb3VwID0gZ2V0R3JvdXAobGluZSk7XG4gICAgICAgIGlmICghIWdyb3VwKVxuICAgICAgICAgICAgcm93Lm91dGxpbmVMZXZlbCA9IDE7XG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIHJvdy5nZXRDZWxsKDEpLnZhbHVlID0gYCR7Y291bnRDbGFzc2lmaWNhdGlvbisrfcK6YDtcbiAgICAgICAgLy9zZXQgbWt0U2hhcmVcbiAgICAgICAgY29uc3QgbWt0U2hhcmUgPSByb3cuZ2V0Q2VsbCg0KTtcbiAgICAgICAgbWt0U2hhcmUudmFsdWUgPSBgJHsocm91bmRfMS5yb3VuZE51bWJlcihsaW5lLnByZW1pb0VtaXRpZG9BdHUgKiAxMDAwIC8gdG90YWxQcmVtaW9FbWl0aWRvLCAxKSAvIDEwKS50b0ZpeGVkKDIpfSVgO1xuICAgICAgICBta3RTaGFyZS5udW1GbXQgPSBcIjAwLjAlXCI7XG4gICAgICAgIGNvbnN0IG1rdFZhciA9IHJvdy5nZXRDZWxsKDYpO1xuICAgICAgICBta3RWYXIudmFsdWUgPSBsaW5lLnByZW1pb0VtaXRpZG9BdHUgPiBsaW5lLnByZW1pb0VtaXRpZG9BbnQgPyAxIDogMDtcbiAgICAgICAgT2JqZWN0LmtleXMobGluZSkuZm9yRWFjaCgocHJvcCwgaSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgaWRDb2wgPSBpICsgMTtcbiAgICAgICAgICAgIGNvbnN0IGNlbGwgPSByb3cuZ2V0Q2VsbChpZENvbCk7XG4gICAgICAgICAgICBpZiAoIXRleHRDb2x1bW5zLmZpbmQodiA9PiB2ID09IGlkQ29sKSkge1xuICAgICAgICAgICAgICAgIGNlbGwubnVtRm10ID0gaGFzRGVjaW1hbFBsYWNlcyhsaW5lW3Byb3BdKSA/IGRlY2ltYWxGb3JtYXR0aW5nIDogaW50Rm9ybWF0dGluZztcbiAgICAgICAgICAgICAgICBhbGlnblJpZ2h0KGNlbGwpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlkQ29sID09PSAyKVxuICAgICAgICAgICAgICAgIGFsaWduTGVmdChjZWxsKTtcbiAgICAgICAgICAgIGlmIChsaXN0Q2VudGVyZWQuZmluZChjID0+IGMgPT09IGlkQ29sKSlcbiAgICAgICAgICAgICAgICBhbGlnbkNlbnRlcihjZWxsKTtcbiAgICAgICAgICAgIGNlbGwuYm9yZGVyID0gYm9yZGVyO1xuICAgICAgICAgICAgY2VsbC5mb250ID0ge1xuICAgICAgICAgICAgICAgIG5hbWU6ICdWZXJkYW5hJyxcbiAgICAgICAgICAgICAgICBzaXplOiA5LFxuICAgICAgICAgICAgICAgIGNvbG9yOiB7IGFyZ2I6IFwiMzMzMzMzXCIgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGlmIChsaW5lLmlzQXhhKSB7XG4gICAgICAgICAgICAgICAgY2VsbC5mb250ID0ge1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiAnVmVyZGFuYScsXG4gICAgICAgICAgICAgICAgICAgIHNpemU6IDksXG4gICAgICAgICAgICAgICAgICAgIGJvbGQ6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiB7IGFyZ2I6IFwiMzMzMzMzXCIgfVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgY2VsbC5maWxsID0ge1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcInBhdHRlcm5cIixcbiAgICAgICAgICAgICAgICAgICAgcGF0dGVybjogXCJzb2xpZFwiLFxuICAgICAgICAgICAgICAgICAgICBmZ0NvbG9yOiB7IGFyZ2I6IFwiRkZGRjAwXCIgfVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xuICAgIEFycmF5LmZyb20oeyBsZW5ndGg6IHNraXBMaW5lc1RpdGxlIH0sIChhLCBpKSA9PiBzaGVldC5jb2x1bW5zLmZvckVhY2goKGNvbCwgeikgPT4gc2l0eWxpbmdUaXRsZShzaGVldC5nZXRSb3coaSArIDEpLmdldENlbGwoeiArIDEpKSkpO1xuICAgIHNoZWV0LmdldFJvdygxKS5nZXRDZWxsKDEpLnZhbHVlID0gXCJcIjtcbiAgICBzaGVldC5tZXJnZUNlbGxzKFwiQTE6QjFcIik7XG4gICAgc2hlZXQuZ2V0Um93KDEpLmdldENlbGwoMSkuZmlsbCA9IHtcbiAgICAgICAgdHlwZTogXCJwYXR0ZXJuXCIsXG4gICAgICAgIHBhdHRlcm46IFwic29saWRcIixcbiAgICAgICAgZmdDb2xvcjogeyBhcmdiOiBcIkMwMDAwMFwiIH1cbiAgICB9O1xuICAgIGNvbnN0IGNlbGwgPSBzaGVldC5nZXRDZWxsKFwiQTFcIik7XG4gICAgY2VsbC52YWx1ZSA9IGNvbHVtbnNbMV0ubmFtZTtcbiAgICBhbGlnbkNlbnRlcihjZWxsKTtcbiAgICBzaGVldC5wcm9wZXJ0aWVzLm91dGxpbmVMZXZlbFJvdyA9IDE7XG4gICAgbWVzc2FnZXIoeyB0eXBlOiB0eXBlc18xLm1zZ1R5cGUuZmluaXNoaWVzRXhwb3J0U3ByZWFkU2hlZXQgfSk7XG59O1xuY29uc3QgZG93bmxvYWRGaWxlID0gKHdvcmtib29rLCBmaWxlTmFtZSkgPT4gd29ya2Jvb2sueGxzeC53cml0ZUJ1ZmZlcigpXG4gICAgLnRoZW4ocmVzID0+IHtcbiAgICBjb25zdCBkYXRhRmlsZSA9IG5ldyBCbG9iKFtyZXNdLCB7IHR5cGU6IFwib2N0ZXQvc3RyZWFtXCIgfSk7XG4gICAgY29uc3QgdXJsID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoZGF0YUZpbGUpO1xuICAgIGNvbnN0IGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYVwiKTtcbiAgICBhLnNldEF0dHJpYnV0ZShcInN0eWxlXCIsIFwiZGlzcGxheTogbm9uZVwiKTtcbiAgICBhLmhyZWYgPSB1cmw7XG4gICAgYS5kb3dubG9hZCA9IGAke2ZpbGVOYW1lfS54bHN4YDtcbiAgICBhLmNsaWNrKCk7XG4gICAgd2luZG93LlVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcbn0pO1xuIiwiXG5leHBvcnQgY29uc3Qgcm91bmROdW1iZXIgPSAobnVtLCBzY2FsZSkgPT4ge1xuICAgIGlmKCEoXCJcIiArIG51bSkuaW5jbHVkZXMoXCJlXCIpKSB7XG4gICAgICAgIHJldHVybiArKE1hdGgucm91bmQobnVtICsgXCJlK1wiICsgc2NhbGUpICArIFwiZS1cIiArIHNjYWxlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICB2YXIgYXJyID0gKFwiXCIgKyBudW0pLnNwbGl0KFwiZVwiKTtcbiAgICAgICAgdmFyIHNpZyA9IFwiXCJcbiAgICAgICAgaWYoK2FyclsxXSArIHNjYWxlID4gMCkge1xuICAgICAgICAgICAgc2lnID0gXCIrXCI7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICsoTWF0aC5yb3VuZCgrYXJyWzBdICsgXCJlXCIgKyBzaWcgKyAoK2FyclsxXSArIHNjYWxlKSkgKyBcImUtXCIgKyBzY2FsZSk7XG4gICAgfVxufSJdLCJzb3VyY2VSb290IjoiIn0=